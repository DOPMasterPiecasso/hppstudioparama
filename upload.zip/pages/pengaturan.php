<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../auth/AuthMiddleware.php';
// Pengaturan is manager/admin only
$user = requireRole('admin', 'manager');
$pageTitle = 'Pengaturan Harga — Parama Studio';
$currentPage = 'pengaturan';

// Load master data untuk ditampilkan di form
try {
    $db = getDB();
    $settings = $db->getSettings();
    $overhead = $settings['overhead'] ?? [];
    $cetakF = $settings['pricing_factors']['cetak'] ?? ['handy' => 1.0, 'minimal' => 0.95, 'large' => 1.15];
    $alcF = $settings['pricing_factors']['alacarte'] ?? ['ebook' => 0.72, 'editcetak' => 0.62, 'desain' => 0.22, 'cetakonly' => 0.30];
    
    // Load graduation data
    $graduationPath = __DIR__ . '/../data/graduation.json';
    $graduation = [];
    if (file_exists($graduationPath)) {
        $graduation = json_decode(file_get_contents($graduationPath), true) ?? [];
    }
    $gradPackages = $graduation['packages'] ?? [];
    $gradAddons = $graduation['addons'] ?? [];
    $gradCetak = $graduation['cetak'] ?? [];
    
    // Load payment terms data
    $paymentTermsPath = __DIR__ . '/../data/payment_terms.json';
    $paymentTerms = [];
    if (file_exists($paymentTermsPath)) {
        $paymentTermsData = json_decode(file_get_contents($paymentTermsPath), true) ?? [];
        $paymentTerms = $paymentTermsData['terms'] ?? [];
    }
    
} catch (Exception $e) {
    // Fallback to defaults
    $overhead = [
        'Designer' => 16700000,
        'Marketing' => 12750000,
        'Creative Prod.' => 7670000,
        'Project Mgr' => 7200000,
        'Social Media' => 6430000,
        'Freelance' => 3204000,
        'Operasional' => 11586000,
    ];
    $cetakF = ['handy' => 1.0, 'minimal' => 0.95, 'large' => 1.15];
    $alcF = ['ebook' => 0.72, 'editcetak' => 0.62, 'desain' => 0.22, 'cetakonly' => 0.30];
    $gradPackages = [];
    $gradAddons = [];
    $gradCetak = [];
}

include __DIR__ . '/../includes/header.php';
?>
<body>
<!-- Toast Container -->
<div id="toast-container" style="position:fixed;top:20px;right:20px;z-index:2000;max-width:400px"></div>

<!-- Mobile Navbar Fixed -->
<div class="mobile-navbar">
  <button class="mobile-menu-btn" onclick="toggleMobileMenu()">☰</button>
  <div class="mobile-navbar-title">Parama Studio</div>
</div>
<div class="sidebar-overlay" id="sidebar-overlay" onclick="closeMobileMenu()"></div>

<div class="app">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<main class="main">
<!-- PENGATURAN -->
<div class="page active" id="page-pengaturan">
  <div class="ph"><div class="pt">Edit Semua Harga</div><div class="ps">Ubah semua harga &amp; asumsi biaya — berpengaruh ke seluruh dashboard</div></div>
  <div class="card mb16">
    <div class="ct">Overhead &amp; Gaji Tim (Rp/bulan)</div>
    <div class="note mb12">Kelola biaya overhead — edit, tambah item baru, atau hapus. Total overhead akan dihitung otomatis.</div>
    
    <!-- Daftar Overhead Items -->
    <div id="overhead-items" style="margin-bottom:16px">
      <?php foreach ($overhead as $name => $value): ?>
      <div class="overhead-item" data-name="<?= htmlspecialchars($name) ?>" data-value="<?= htmlspecialchars($value) ?>" style="display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center;margin-bottom:8px;padding:10px;background:#fafafa;border-radius:4px">
        <div style="font-size:13px;font-weight:500"><?= htmlspecialchars($name) ?></div>
        <div class="oh-display" style="font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0" onclick="editOHItem('<?= htmlspecialchars($name) ?>')">Rp <?= number_format($value, 0, ',', '.') ?></div>
        <button class="btn bs bsm" onclick="editOHItem('<?= htmlspecialchars($name) ?>')" style="padding:4px 8px;font-size:11px">✏️</button>
        <button class="btn bs bsm" onclick="deleteOHItem('<?= htmlspecialchars($name) ?>')" style="padding:4px 8px;font-size:11px">✕</button>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Add New Overhead Item -->
    <div style="padding:12px;background:#f9f9f9;border-radius:4px;border:1px solid var(--border);margin-bottom:16px">
      <div style="font-size:12px;font-weight:600;color:var(--text2);margin-bottom:8px">Tambah Item Baru</div>
      <div style="display:grid;grid-template-columns:1fr 150px 80px;gap:8px;align-items:center">
        <input type="text" id="new-oh-name" placeholder="Nama cost (cth: Staffing, Asuransi)" style="border:1px solid var(--border);padding:6px 8px;border-radius:3px;font-size:12px">
        <input type="number" id="new-oh-value" placeholder="Nilai Rp" style="border:1px solid var(--border);padding:6px 8px;border-radius:3px;font-size:12px">
        <button class="btn bsm" style="background:#2a6b8a;color:white;border:none;cursor:pointer" onclick="addOHItem()">+ Tambah</button>
      </div>
    </div>

    <!-- Control Buttons -->
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <button class="btn bp bsm" onclick="saveOH()">Simpan Overhead</button>
      <button class="btn bs bsm" onclick="resetOH()">Reset ke Default</button>
      <span id="ov-status" style="font-size:12px;color:var(--success);display:none">✓ Tersimpan</span>
    </div>

    <!-- Total Display -->
    <div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--border)">
      <div style="font-size:12px;color:var(--text2)">Total Overhead Bulanan</div>
      <div id="oh-total" style="font-size:18px;font-weight:600;color:var(--accent)">Rp 0</div>
    </div>
  </div>
  <!-- ===== BIAYA CETAK — RENJANA OFFSET (CRUD MASTER) ===== -->
  <div class="card mb16" id="cetak-master-card">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;margin-bottom:8px">
      <div>
        <div class="ct" style="margin-bottom:4px">Biaya Cetak — Renjana Offset</div>
        <div style="font-size:12px;color:var(--text2)">Master harga dasar per buku per range siswa. Edit langsung kalau harga vendor naik.</div>
      </div>
      <button class="btn bp bsm" onclick="showAddRangeModal()" style="flex-shrink:0">+ Tambah Range</button>
    </div>
    <div class="note mb12">Pilih range siswa untuk melihat/edit tabel harga. Klik angka untuk ubah. Perubahan tersimpan otomatis ke master data.</div>

    <!-- Range selector buttons — dirender PHP -->
    <div style="margin-bottom:12px">
      <div style="font-size:12px;font-weight:600;color:var(--text2);margin-bottom:6px">Pilih Range Siswa</div>
      <div style="display:flex;gap:5px;flex-wrap:wrap" id="cetak-range-btns">
        <?php
        $cetakBaseData = [];
        try {
            $db2 = getDB();
            $cetakBaseData = $db2->getCetakBase();
        } catch (Exception $e) { $cetakBaseData = []; }
        if (empty($cetakBaseData)) {
            $cetakBaseData = [
                ['lo'=>30,'hi'=>50,'label'=>'30–50 siswa'],['lo'=>51,'hi'=>75,'label'=>'51–75 siswa'],
                ['lo'=>76,'hi'=>100,'label'=>'76–100 siswa'],['lo'=>101,'hi'=>125,'label'=>'101–125 siswa'],
                ['lo'=>126,'hi'=>150,'label'=>'126–150 siswa'],['lo'=>151,'hi'=>175,'label'=>'151–175 siswa'],
                ['lo'=>176,'hi'=>200,'label'=>'176–200 siswa'],['lo'=>201,'hi'=>225,'label'=>'201–225 siswa'],
                ['lo'=>226,'hi'=>250,'label'=>'226–250 siswa'],['lo'=>251,'hi'=>275,'label'=>'251–275 siswa'],
                ['lo'=>276,'hi'=>300,'label'=>'276–300 siswa'],['lo'=>301,'hi'=>325,'label'=>'301–325 siswa'],
                ['lo'=>326,'hi'=>350,'label'=>'326–350 siswa'],['lo'=>351,'hi'=>375,'label'=>'351–375 siswa'],
                ['lo'=>376,'hi'=>400,'label'=>'376–400 siswa'],['lo'=>401,'hi'=>425,'label'=>'401–425 siswa'],
                ['lo'=>426,'hi'=>450,'label'=>'426–450 siswa'],['lo'=>451,'hi'=>475,'label'=>'451–475 siswa'],
                ['lo'=>476,'hi'=>500,'label'=>'476–500 siswa'],
            ];
        }
        foreach ($cetakBaseData as $idx => $range): ?>
        <button class="btn <?= $idx===0?'bp':'bs' ?> bsm cetak-range-btn" onclick="setCetakRange(<?= $idx ?>, this)" style="font-size:11px;position:relative">
          <?= htmlspecialchars($range['label']) ?>
          <span class="cetak-del-btn" onclick="deleteCetakRange(event,<?= $idx ?>)" title="Hapus range" style="margin-left:5px;color:var(--danger);font-weight:700;font-size:13px;line-height:1">×</span>
        </button>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Tabel harga per halaman untuk range yang dipilih -->
    <div class="tw" id="cetak-table-wrap" style="min-height:80px"></div>

    <!-- Add halaman baru ke range aktif -->
    <div id="cetak-add-hal-row" style="display:flex;gap:8px;align-items:center;margin-top:10px;flex-wrap:wrap;padding:10px;background:var(--surface2);border-radius:8px;border:1px dashed var(--border2)">
      <div style="font-size:12px;font-weight:600;color:var(--text2)">+ Tambah Tier Halaman:</div>
      <input type="number" id="new-hal-pages" placeholder="Jml halaman" min="1" max="500" style="width:110px;font-size:12px;padding:4px 8px">
      <input type="number" id="new-hal-price" placeholder="Harga/buku (Rp)" min="0" style="width:150px;font-size:12px;padding:4px 8px">
      <button class="btn bp bsm" onclick="addHalamanTier()">Tambah</button>
    </div>

    <!-- Status & Simpan -->
    <div style="display:flex;gap:8px;align-items:center;margin-top:12px;flex-wrap:wrap">
      <button class="btn bp bsm" onclick="saveCetakBase()">💾 Simpan Semua Perubahan</button>
      <button class="btn bs bsm" onclick="resetCetakBase()">↩ Reset ke Default Renjana</button>
      <span id="ov-cetak-status" style="font-size:12px;color:var(--success);display:none">✓ Tersimpan</span>
    </div>

    <!-- Faktor per paket -->
    <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--border)">
      <div style="font-size:12px;font-weight:600;color:var(--text2);margin-bottom:8px">Faktor Multiplier per Paket <span style="font-weight:400;color:var(--text3)">(harga efektif = base × faktor)</span></div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:9px;margin-bottom:10px">
        <div class="fg"><label class="fl">Handy Book A4+</label><div style="display:flex;align-items:center;gap:5px"><input type="number" id="ov-cetak-handy" value="<?= htmlspecialchars($cetakF['handy'] ?? '1.00') ?>" step="0.01" min="0.5" max="3"><span style="font-size:12px;color:var(--text3)">×</span></div></div>
        <div class="fg"><label class="fl">Minimal Book SQ</label><div style="display:flex;align-items:center;gap:5px"><input type="number" id="ov-cetak-minimal" value="<?= htmlspecialchars($cetakF['minimal'] ?? '0.95') ?>" step="0.01" min="0.5" max="3"><span style="font-size:12px;color:var(--text3)">×</span></div></div>
        <div class="fg"><label class="fl">Large Book B4</label><div style="display:flex;align-items:center;gap:5px"><input type="number" id="ov-cetak-large" value="<?= htmlspecialchars($cetakF['large'] ?? '1.15') ?>" step="0.01" min="0.5" max="3"><span style="font-size:12px;color:var(--text3)">×</span></div></div>
      </div>
      <button class="btn bp bsm" onclick="saveCetak()">💾 Simpan Faktor Paket</button>
    </div>
  </div>

  <!-- Modal: Tambah Range Baru -->
  <div id="modal-add-range" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;align-items:center;justify-content:center">
    <div class="modal-box" style="max-width:420px">
      <div class="modal-title">Tambah Range Siswa Baru</div>
      <div class="form-row">
        <label>Jumlah Siswa Minimum</label>
        <input type="number" id="new-range-lo" placeholder="cth: 501" min="1" max="9999">
      </div>
      <div class="form-row">
        <label>Jumlah Siswa Maximum</label>
        <input type="number" id="new-range-hi" placeholder="cth: 525" min="1" max="9999">
      </div>
      <div class="form-row">
        <label>Label Tampilan <span style="color:var(--text3);font-size:11px">(opsional, otomatis)</span></label>
        <input type="text" id="new-range-label" placeholder="cth: 501–525 siswa">
      </div>
      <div class="note mb12" style="margin-top:4px">Range baru akan dibuat dengan harga default. Edit harga setelah range dibuat.</div>
      <div style="display:flex;gap:8px;margin-top:16px">
        <button class="btn bp" style="flex:1" onclick="confirmAddRange()">Tambah Range</button>
        <button class="btn bs" onclick="closeAddRangeModal()">Batal</button>
      </div>
    </div>
  </div>


  <div class="card mb16">
    <div class="ct">Faktor Harga À La Carte (% dari Full Service)</div>
    <div class="note mb12">Harga à la carte = harga full service × faktor ini.</div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:9px;margin-bottom:12px">
      <div class="fg"><label class="fl">E-Book Package (%)</label><input type="number" id="ov-ac-ebook" value="<?= htmlspecialchars($alcF['ebook'] ?? 72) ?>" min="10" max="100"></div>
      <div class="fg"><label class="fl">Edit+Desain+Cetak (%)</label><input type="number" id="ov-ac-editcetak" value="<?= htmlspecialchars($alcF['editcetak'] ?? 62) ?>" min="10" max="100"></div>
      <div class="fg"><label class="fl">Desain Only (%)</label><input type="number" id="ov-ac-desain" value="<?= htmlspecialchars($alcF['desain'] ?? 22) ?>" min="10" max="100"></div>
      <div class="fg"><label class="fl">Cetak Only (%)</label><input type="number" id="ov-ac-cetakonly" value="<?= htmlspecialchars($alcF['cetakonly'] ?? 30) ?>" min="10" max="100"></div>
    </div>
    <button class="btn bp bsm" onclick="saveALC()">Simpan Faktor À La Carte</button>
  </div>

  <!-- ===== GRADUATION SECTION ===== -->
  <div class="card mb16">
    <div class="ph"><div class="pt" style="color:var(--grad)">Graduation Package</div><div class="ps">Dokumentasi wisuda — foto, video, photobooth &amp; glamation 360°</div></div>
    <div class="note grad mb16">✏️ Klik angka harga mana saja untuk edit langsung. Semua harga juga bisa diubah di menu <b>Edit Semua Harga</b>.</div>

    <div class="sec">Edit Harga Paket Utama</div>
    <div class="note mb12">Kelola paket utama — edit, tambah item baru, atau hapus.</div>
    
    <!-- Daftar Paket Items -->
    <div id="grad-pkg-items" style="margin-bottom:16px">
      <?php foreach ($gradPackages as $pkg): ?>
      <div class="grad-pkg-item" data-id="<?= htmlspecialchars($pkg['id']) ?>" data-name="<?= htmlspecialchars($pkg['name']) ?>" data-price="<?= htmlspecialchars($pkg['price']) ?>" data-desc="<?= htmlspecialchars($pkg['desc'] ?? '') ?>" style="margin-bottom:8px;padding:10px;background:#fafafa;border-radius:4px;border:1px solid var(--border);display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center">
        <div style="font-size:13px;font-weight:500"><?= htmlspecialchars($pkg['name']) ?></div>
        <div class="gp-display" style="font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0" onclick="editGradPkg('<?= htmlspecialchars($pkg['id']) ?>')">Rp <?= number_format($pkg['price'], 0, ',', '.') ?></div>
        <button class="btn bs bsm btn-edit-price" data-id="<?= htmlspecialchars($pkg['id']) ?>" style="padding:4px 8px;font-size:11px;cursor:pointer">✏️</button>
        <button class="btn bs bsm btn-delete" data-id="<?= htmlspecialchars($pkg['id']) ?>" style="padding:4px 8px;font-size:11px;cursor:pointer">✕</button>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Add New Package Item -->
    <div style="padding:12px;background:#f9f9f9;border-radius:4px;border:1px solid var(--border);margin-bottom:16px">
      <div style="font-size:12px;font-weight:600;color:var(--text2);margin-bottom:8px">Tambah Paket Baru</div>
      <div style="display:grid;grid-template-columns:1fr 150px 80px;gap:8px;margin-bottom:8px;align-items:center">
        <input type="text" id="new-grad-pkg-name" placeholder="Nama paket (cth: Paket Promo, Paket VIP)" style="border:1px solid var(--border);padding:6px 8px;border-radius:3px;font-size:12px">
        <input type="number" id="new-grad-pkg-price" placeholder="Harga Rp" style="border:1px solid var(--border);padding:6px 8px;border-radius:3px;font-size:12px">
        <button class="btn bsm" style="background:#2a6b8a;color:white;border:none;cursor:pointer" onclick="addGradPkg()">+ Tambah</button>
      </div>
      <div style="margin-bottom:8px">
        <label style="font-size:11px;font-weight:600;color:var(--text3);display:block;margin-bottom:4px">Deskripsi (opsional)</label>
        <textarea id="new-grad-pkg-desc" placeholder="Deskripsi singkat paket..." style="width:100%;min-height:50px;border:1px solid var(--border);padding:6px 8px;border-radius:3px;font-size:12px;font-family:inherit"></textarea>
      </div>
    </div>

    <!-- Control Buttons -->
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <button class="btn bgrad bsm" onclick="saveGrad()">Simpan Harga Paket</button>
      <button class="btn bs bsm" onclick="resetGrad()">Reset ke Default</button>
      <span id="grad-pkg-status" style="font-size:12px;color:var(--success);display:none">✓ Tersimpan</span>
    </div>

    <div class="sec">Edit Add-on &amp; Cetak Foto</div>
    <div class="note mb12">Kelola add-on dan cetak foto — edit harga, tambah item baru, atau hapus.</div>
    
    <!-- Daftar Add-on Items -->
    <div style="margin-bottom:16px">
      <div style="font-size:12px;font-weight:600;color:var(--text2);margin-bottom:8px">Add-on Graduation</div>
      <div id="grad-addon-items" style="margin-bottom:12px">
        <?php foreach ($gradAddons as $addon): ?>
        <div class="grad-addon-item" data-id="<?= htmlspecialchars($addon['id']) ?>" data-name="<?= htmlspecialchars($addon['name']) ?>" data-price="<?= htmlspecialchars($addon['price']) ?>" style="display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center;margin-bottom:8px;padding:10px;background:#fafafa;border-radius:4px">
          <div style="font-size:13px;font-weight:500"><?= htmlspecialchars($addon['name']) ?></div>
          <div class="ga-display" style="font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0" onclick="editGradAddon('<?= htmlspecialchars($addon['id']) ?>')">Rp <?= number_format($addon['price'], 0, ',', '.') ?></div>
          <button class="btn bs bsm" onclick="editGradAddon('<?= htmlspecialchars($addon['id']) ?>')" style="padding:4px 8px;font-size:11px">✏️</button>
          <button class="btn bs bsm" onclick="deleteGradAddon('<?= htmlspecialchars($addon['id']) ?>')" style="padding:4px 8px;font-size:11px">✕</button>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Add New Add-on Item -->
    <div style="padding:12px;background:#f9f9f9;border-radius:4px;border:1px solid var(--border);margin-bottom:16px">
      <div style="font-size:12px;font-weight:600;color:var(--text2);margin-bottom:8px">Tambah Add-on Baru</div>
      <div style="display:grid;grid-template-columns:1fr 150px 80px;gap:8px;align-items:center">
        <input type="text" id="new-grad-addon-name" placeholder="Nama add-on (cth: Tambah 2 Jam)" style="border:1px solid var(--border);padding:6px 8px;border-radius:3px;font-size:12px">
        <input type="number" id="new-grad-addon-price" placeholder="Harga Rp" style="border:1px solid var(--border);padding:6px 8px;border-radius:3px;font-size:12px">
        <button class="btn bsm" style="background:#2a6b8a;color:white;border:none;cursor:pointer" onclick="addGradAddon()">+ Tambah</button>
      </div>
    </div>

    <!-- Daftar Cetak Items -->
    <div style="margin-bottom:16px">
      <div style="font-size:12px;font-weight:600;color:var(--text2);margin-bottom:8px">Cetak Foto Tambahan</div>
      <div id="grad-cetak-items" style="margin-bottom:12px">
        <?php foreach ($gradCetak as $cetak): ?>
        <div class="grad-cetak-item" data-id="<?= htmlspecialchars($cetak['id']) ?>" data-name="<?= htmlspecialchars($cetak['name']) ?>" data-price="<?= htmlspecialchars($cetak['price']) ?>" style="display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center;margin-bottom:8px;padding:10px;background:#fafafa;border-radius:4px">
          <div style="font-size:13px;font-weight:500"><?= htmlspecialchars($cetak['name']) ?></div>
          <div class="gc-display" style="font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0" onclick="editGradCetak('<?= htmlspecialchars($cetak['id']) ?>')">Rp <?= number_format($cetak['price'], 0, ',', '.') ?></div>
          <button class="btn bs bsm" onclick="editGradCetak('<?= htmlspecialchars($cetak['id']) ?>')" style="padding:4px 8px;font-size:11px">✏️</button>
          <button class="btn bs bsm" onclick="deleteGradCetak('<?= htmlspecialchars($cetak['id']) ?>')" style="padding:4px 8px;font-size:11px">✕</button>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Add New Cetak Item -->
    <div style="padding:12px;background:#f9f9f9;border-radius:4px;border:1px solid var(--border);margin-bottom:16px">
      <div style="font-size:12px;font-weight:600;color:var(--text2);margin-bottom:8px">Tambah Cetak Baru</div>
      <div style="display:grid;grid-template-columns:1fr 150px 80px;gap:8px;align-items:center">
        <input type="text" id="new-grad-cetak-name" placeholder="Nama (cth: Cetak Foto A5)" style="border:1px solid var(--border);padding:6px 8px;border-radius:3px;font-size:12px">
        <input type="number" id="new-grad-cetak-price" placeholder="Harga Rp" style="border:1px solid var(--border);padding:6px 8px;border-radius:3px;font-size:12px">
        <button class="btn bsm" style="background:#2a6b8a;color:white;border:none;cursor:pointer" onclick="addGradCetak()">+ Tambah</button>
      </div>
    </div>

    <!-- Control Buttons -->
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <button class="btn bgrad bsm" onclick="saveGradAddon()">Simpan Add-on &amp; Cetak</button>
      <span id="grad-addon-status" style="font-size:12px;color:var(--success);display:none">✓ Tersimpan</span>
    </div>

    <hr style="margin:20px 0;border:none;border-top:1px solid var(--border)">

    <div class="sec">Paket Utama</div>
    <div class="pkgrid mb20" id="grad-grid"></div>

    <div class="g2 mb20">
      <div>
        <div class="sec">Add-on Graduation</div>
        <div class="card"><div class="tw"><table><thead><tr><th>Item</th><th>Harga</th></tr></thead><tbody id="grad-addon"></tbody></table></div></div>
      </div>
      <div>
        <div class="sec">Cetak Foto Tambahan</div>
        <div class="card"><div class="tw"><table><thead><tr><th>Ukuran</th><th>Harga/lembar</th></tr></thead><tbody id="grad-cetak"></tbody></table></div></div>
      </div>
    </div>

    <div class="card">
      <div class="grad-card-header">Kalkulator Graduation</div>
      <div class="g2">
        <div>
          <div class="fg mb12">
            <label class="fl">Pilih Paket</label>
            <select id="gc-pkg" onchange="gcUpdate()"><option value="">— Pilih paket —</option></select>
          </div>
          <div id="gc-addons"></div>
        </div>
        <div>
          <div class="ct">Ringkasan</div>
          <div id="gc-result"></div>
          <div style="margin-top:10px;padding-top:8px;border-top:1px solid var(--border)">
            <div class="rr tot"><span class="rl">Total</span><span class="rv" id="gc-total" style="color:var(--grad)">—</span></div>
          </div>
          <div id="gc-note" class="note grad mt10"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- ===== PAYMENT TERMS SECTION ===== -->
  <div class="card mb16">
    <div class="ph"><div class="pt" style="color:#9B59B6">Syarat Pembayaran</div><div class="ps">Kelola opsi pembayaran untuk penawaran dan proyek — DP, cicilan, atau pembayaran penuh</div></div>
    <div class="note grad mb16">💳 Kelola syarat pembayaran yang tersedia untuk penawaran proyek Anda. Setiap syarat mencakup persentase DP, deskripsi, dan warna penanda.</div>

    <div class="sec">Kelola Syarat Pembayaran</div>
    <div class="note mb12">Edit, tambah, atau hapus opsi pembayaran — perubahan tersimpan otomatis.</div>
    
    <!-- Daftar Payment Terms Items -->
    <div id="pt-items" style="margin-bottom:16px">
      <?php foreach ($paymentTerms as $term): ?>
      <div class="pt-item" data-id="<?= htmlspecialchars($term['id']) ?>" data-name="<?= htmlspecialchars($term['name']) ?>" data-deposit="<?= htmlspecialchars($term['deposit']) ?>" data-desc="<?= htmlspecialchars($term['desc'] ?? '') ?>" data-color="<?= htmlspecialchars($term['color'] ?? '#9B59B6') ?>" style="margin-bottom:8px;padding:10px;background:#fafafa;border-radius:4px;border:1px solid var(--border);display:grid;grid-template-columns:auto 1fr auto auto auto;gap:12px;align-items:center">
        <div style="width:20px;height:20px;border-radius:3px;background:<?= htmlspecialchars($term['color'] ?? '#9B59B6') ?>;border:1px solid rgba(0,0,0,0.1)"></div>
        <div style="flex:1">
          <div style="font-size:13px;font-weight:600"><?= htmlspecialchars($term['name']) ?></div>
          <div style="font-size:11px;color:var(--text3);margin-top:2px">DP: <?= htmlspecialchars($term['deposit']) ?>%</div>
        </div>
        <div style="font-size:12px;color:var(--text2);min-width:200px"><?= htmlspecialchars($term['desc'] ?? '—') ?></div>
        <button class="btn bs bsm btn-edit-pt" data-id="<?= htmlspecialchars($term['id']) ?>" style="padding:4px 8px;font-size:11px;cursor:pointer">✏️</button>
        <button class="btn bs bsm btn-delete-pt" data-id="<?= htmlspecialchars($term['id']) ?>" style="padding:4px 8px;font-size:11px;cursor:pointer">✕</button>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Add New Payment Term Item -->
    <div style="padding:12px;background:#f9f9f9;border-radius:4px;border:1px solid var(--border);margin-bottom:16px">
      <div style="font-size:12px;font-weight:600;color:var(--text2);margin-bottom:8px">Tambah Syarat Pembayaran Baru</div>
      <div style="display:grid;grid-template-columns:1fr 80px 80px 80px;gap:8px;margin-bottom:8px;align-items:center">
        <input type="text" id="new-pt-name" placeholder="Nama (cth: DP 50%)" style="border:1px solid var(--border);padding:6px 8px;border-radius:3px;font-size:12px">
        <input type="number" id="new-pt-deposit" placeholder="DP %" min="0" max="100" style="border:1px solid var(--border);padding:6px 8px;border-radius:3px;font-size:12px">
        <input type="color" id="new-pt-color" value="#9B59B6" style="border:1px solid var(--border);padding:4px;border-radius:3px;height:32px;cursor:pointer">
        <button class="btn bsm" style="background:#2a6b8a;color:white;border:none;cursor:pointer" onclick="addPaymentTerm()">+ Tambah</button>
      </div>
      <div style="margin-bottom:0">
        <label style="font-size:11px;font-weight:600;color:var(--text3);display:block;margin-bottom:4px">Deskripsi (opsional)</label>
        <textarea id="new-pt-desc" placeholder="Contoh: Pembayaran 50% di awal, 50% saat selesai..." style="width:100%;min-height:50px;border:1px solid var(--border);padding:6px 8px;border-radius:3px;font-size:12px;font-family:inherit"></textarea>
      </div>
    </div>

    <!-- Control Buttons -->
    <div style="display:none">
      <button class="btn bs bsm" onclick="resetPaymentTerms()">Reset ke Default</button>
    </div>
  </div>
</div>
</main>
</div>

<!-- Modal untuk Full Service Editor -->
<div id="fs-modal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);z-index:1000;align-items:center;justify-content:center">
  <div style="background:white;padding:30px;border-radius:10px;max-width:600px;max-height:80vh;overflow-y:auto;width:90%">
    <div style="font-size:18px;font-weight:600;margin-bottom:20px">Edit Full Service Pricing</div>
    <div id="fs-modal-content"></div>
    <div style="margin-top:20px;display:flex;gap:10px">
      <button class="btn bp" onclick="saveFSModal()">Simpan</button>
      <button class="btn bs" onclick="closeFSModal()">Batal</button>
    </div>
  </div>
</div>

<?php
$jsUser = json_encode([
    'id'       => $user['id'],
    'name'     => $user['name'],
    'role'     => $user['role'],
    'isManager'=> $isManager,
    'isAdmin'  => $isAdmin,
]);
?>
<script src="/assets/js/app.js"></script>
<script src="/assets/js/app-pages.js"></script>
<script>
const PHP_USER = <?= $jsUser ?>;
// MASTER_API sudah didefinisikan di header.php — jangan redeclare
</script>
<script>
// ============================================================
// MASTER DATA EDITOR — pengaturan.php
// Semua perubahan disimpan via /api/master-data.php
// ============================================================

// Toast Notification System
function showToast(message, type = 'success', duration = 3000) {
    const container = document.getElementById('toast-container');
    
    // Color mapping
    const colors = {
        'success': { bg: '#e8f5e9', border: '#4caf50', icon: '✓', color: '#2e7d32' },
        'error': { bg: '#ffebee', border: '#f44336', icon: '✕', color: '#c62828' },
        'info': { bg: '#e3f2fd', border: '#2196f3', icon: 'ℹ', color: '#1565c0' },
        'warning': { bg: '#fff3e0', border: '#ff9800', icon: '⚠', color: '#e65100' }
    };
    
    const style = colors[type] || colors.info;
    
    const toast = document.createElement('div');
    toast.style.cssText = `
        background: ${style.bg};
        border-left: 4px solid ${style.border};
        padding: 14px 16px;
        border-radius: 4px;
        margin-bottom: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        display: flex;
        align-items: center;
        gap: 12px;
        font-size: 13px;
        color: ${style.color};
        font-weight: 500;
        animation: slideInRight 0.3s ease-out;
    `;
    
    toast.innerHTML = `
        <span style="font-size: 16px; font-weight: 600;">${style.icon}</span>
        <span>${message}</span>
    `;
    
    container.appendChild(toast);
    
    // Auto remove
    setTimeout(() => {
        toast.style.animation = 'slideOutRight 0.3s ease-out';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// Add CSS animations if not already present
if (!document.getElementById('toast-animations')) {
    const style = document.createElement('style');
    style.id = 'toast-animations';
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(400px);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
}

// Save functions untuk setiap section
async function saveOH() {
    // Collect all overhead items from data attributes
    const overhead = {};
    document.querySelectorAll('.overhead-item').forEach(item => {
        const name = item.dataset.name;
        const value = parseInt(item.dataset.value || 0);
        overhead[name] = value;
    });
    
    // Validate - must have at least one item
    if (Object.keys(overhead).length === 0) {
        showToast('Minimal harus ada 1 item overhead', 'error');
        return;
    }
    
    const success = await updateMasterData('overhead', overhead);
    if (success) {
        showToast('✓ Overhead berhasil tersimpan', 'success');
        updateOHTotal();
    } else {
        showToast('✕ Gagal menyimpan overhead', 'error');
    }
}

function updateOHTotal() {
    let total = 0;
    document.querySelectorAll('.overhead-item').forEach(item => {
        const value = parseInt(item.dataset.value || 0);
        total += value;
    });
    document.getElementById('oh-total').textContent = 'Rp ' + total.toLocaleString('id-ID');
}

function editOHItem(name) {
    const item = document.querySelector(`.overhead-item[data-name="${name}"]`);
    if (!item) return;
    
    const value = item.dataset.value;
    const display = item.querySelector('.oh-display');
    const editBtn = item.querySelector('button:nth-child(3)');
    const deleteBtn = item.querySelector('button:nth-child(4)');
    
    // Hide display, show edit mode
    const input = document.createElement('input');
    input.type = 'number';
    input.className = 'oh-edit-input';
    input.value = value;
    input.style.cssText = 'border:2px solid var(--accent);padding:6px 8px;border-radius:3px;font-size:13px;font-weight:600;width:120px;text-align:right';
    
    const saveBtn = document.createElement('button');
    saveBtn.className = 'btn bsm';
    saveBtn.style.cssText = 'background:#4caf50;color:white;border:none;cursor:pointer;padding:4px 8px;font-size:11px';
    saveBtn.textContent = '💾';
    saveBtn.onclick = () => saveOHItemEdit(name);
    
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'btn bs bsm';
    cancelBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    cancelBtn.textContent = '✕';
    cancelBtn.onclick = () => cancelOHItemEdit(name);
    
    // Replace display with input
    display.replaceWith(input);
    editBtn.textContent = '✓';
    editBtn.onclick = () => saveOHItemEdit(name);
    editBtn.style.cssText = 'padding:4px 8px;font-size:11px;background:#4caf50;color:white;border:none;cursor:pointer';
    
    // Replace delete button with cancel
    deleteBtn.replaceWith(cancelBtn);
    
    // Focus input
    input.focus();
    input.select();
}

function saveOHItemEdit(name) {
    const item = document.querySelector(`.overhead-item[data-name="${name}"]`);
    if (!item) return;
    
    const input = item.querySelector('.oh-edit-input');
    const newValue = parseInt(input.value || 0);
    
    if (newValue <= 0) {
        showToast('Nilai harus lebih dari 0', 'warning');
        input.focus();
        return;
    }
    
    // Update data and display
    item.dataset.value = newValue;
    
    const display = document.createElement('div');
    display.className = 'oh-display';
    display.style.cssText = 'font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0';
    display.textContent = 'Rp ' + newValue.toLocaleString('id-ID');
    display.onclick = () => editOHItem(name);
    
    const editBtn = item.querySelector('button:nth-child(3)');
    const saveBtn = item.querySelector('button:nth-child(4)');
    
    // Restore buttons
    input.replaceWith(display);
    editBtn.textContent = '✏️';
    editBtn.onclick = () => editOHItem(name);
    editBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn bs bsm';
    deleteBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    deleteBtn.textContent = '✕';
    deleteBtn.onclick = () => deleteOHItem(name);
    saveBtn.replaceWith(deleteBtn);
    
    updateOHTotal();
    showToast('✓ Item "' + name + '" diperbarui', 'success');
}

function cancelOHItemEdit(name) {
    const item = document.querySelector(`.overhead-item[data-name="${name}"]`);
    if (!item) return;
    
    const value = item.dataset.value;
    
    const display = document.createElement('div');
    display.className = 'oh-display';
    display.style.cssText = 'font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0';
    display.textContent = 'Rp ' + parseInt(value).toLocaleString('id-ID');
    display.onclick = () => editOHItem(name);
    
    const input = item.querySelector('.oh-edit-input');
    input.replaceWith(display);
    
    const editBtn = item.querySelector('button:nth-child(3)');
    editBtn.textContent = '✏️';
    editBtn.onclick = () => editOHItem(name);
    editBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    
    const cancelBtn = item.querySelector('button:nth-child(4)');
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn bs bsm';
    deleteBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    deleteBtn.textContent = '✕';
    deleteBtn.onclick = () => deleteOHItem(name);
    cancelBtn.replaceWith(deleteBtn);
}

function addOHItem() {
    const name = document.getElementById('new-oh-name').value.trim();
    const value = parseInt(document.getElementById('new-oh-value').value || 0);
    
    if (!name) {
        showToast('Nama item tidak boleh kosong', 'warning');
        return;
    }
    
    if (value <= 0) {
        showToast('Nilai harus lebih dari 0', 'warning');
        return;
    }
    
    // Check if item already exists
    const existing = document.querySelector(`.overhead-item[data-name="${name}"]`);
    if (existing) {
        showToast('Item "' + name + '" sudah ada', 'warning');
        return;
    }
    
    // Create new item element with display text + edit button
    const newItem = document.createElement('div');
    newItem.className = 'overhead-item';
    newItem.dataset.name = name;
    newItem.dataset.value = value;
    newItem.style.cssText = 'display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center;margin-bottom:8px;padding:10px;background:#fafafa;border-radius:4px';
    
    newItem.innerHTML = `
        <div style="font-size:13px;font-weight:500">${escapeHtml(name)}</div>
        <div class="oh-display" style="font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0" onclick="editOHItem('${escapeHtml(name)}')">Rp ${value.toLocaleString('id-ID')}</div>
        <button class="btn bs bsm" onclick="editOHItem('${escapeHtml(name)}')" style="padding:4px 8px;font-size:11px">✏️</button>
        <button class="btn bs bsm" onclick="deleteOHItem('${escapeHtml(name)}')" style="padding:4px 8px;font-size:11px">✕</button>
    `;
    
    document.getElementById('overhead-items').appendChild(newItem);
    
    // Clear form
    document.getElementById('new-oh-name').value = '';
    document.getElementById('new-oh-value').value = '';
    
    updateOHTotal();
    showToast('✓ Item "' + name + '" ditambahkan', 'success');
}

function deleteOHItem(name) {
    const item = document.querySelector(`.overhead-item[data-name="${name}"]`);
    if (!item) return;
    
    // Animate removal
    item.style.opacity = '0.5';
    item.style.textDecoration = 'line-through';
    
    setTimeout(() => {
        item.remove();
        updateOHTotal();
        showToast('✓ Item "' + name + '" dihapus', 'success');
        // Auto-save after delete
        saveOH();
    }, 300);
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return String(text ?? '').replace(/[&<>"']/g, m => map[m]);
}

async function resetOH() {
    showToast('⏳ Memproses reset...', 'info');
    const defaults = {
        'Designer': 16700000,
        'Marketing': 12750000,
        'Creative Prod.': 7670000,
        'Project Mgr': 7200000,
        'Social Media': 6430000,
        'Freelance': 3204000,
        'Operasional': 11586000,
    };
    
    const success = await updateMasterData('overhead', defaults);
    if (success) {
        showToast('✓ Data overhead direset ke default', 'success');
        setTimeout(() => location.reload(), 1500);
    } else {
        showToast('✕ Gagal mereset overhead', 'error');
    }
}

async function saveCetakBase() {
    // Implementasi sesuai struktur cetak base
    const status = document.getElementById('ov-cetak-status');
    status.style.display = 'block';
    setTimeout(() => status.style.display = 'none', 2000);
}

async function resetCetakBase() {
    if (!confirm('Reset ke nilai default Renjana?')) return;
    // Reset logic here
}

async function saveCetak() {
    const cetakF = {
        'handy': parseFloat(document.getElementById('ov-cetak-handy')?.value || 1.0),
        'minimal': parseFloat(document.getElementById('ov-cetak-minimal')?.value || 0.95),
        'large': parseFloat(document.getElementById('ov-cetak-large')?.value || 1.15),
    };
    
    const success = await updateMasterData('cetak_factors', cetakF);
    if (success) {
        CETAK_F = {...cetakF};
        showToast('✓ Faktor cetak berhasil tersimpan', 'success');
    } else {
        showToast('✕ Gagal menyimpan faktor cetak', 'error');
    }
}

async function saveALC() {
    const alcF = {
        'ebook': parseInt(document.getElementById('ov-ac-ebook')?.value || 72),
        'editcetak': parseInt(document.getElementById('ov-ac-editcetak')?.value || 62),
        'desain': parseInt(document.getElementById('ov-ac-desain')?.value || 22),
        'cetakonly': parseInt(document.getElementById('ov-ac-cetakonly')?.value || 30),
    };
    
    const success = await updateMasterData('alacarte_factors', alcF);
    if (success) {
        ALC_F = {...alcF};
        showToast('✓ Faktor À La Carte berhasil tersimpan', 'success');
    } else {
        showToast('✕ Gagal menyimpan faktor À La Carte', 'error');
    }
}

async function saveGrad() {
    // Collect graduation package prices from data attributes
    const packages = [];
    document.querySelectorAll('.grad-pkg-item').forEach(item => {
        packages.push({
            id: item.dataset.id,
            name: item.dataset.name,
            price: parseInt(item.dataset.price || 0),
            desc: item.dataset.desc || ''
        });
    });
    
    // Update GRAD object and save
    GRAD.packages = packages;
    
    const success = await updateMasterData('graduation', GRAD);
    if (success) {
        renderGraduation();
        showToast('✓ Harga Paket berhasil tersimpan', 'success');
    } else {
        showToast('✕ Gagal menyimpan harga paket', 'error');
    }
}

function editGradPkg(id) {
    const item = document.querySelector(`.grad-pkg-item[data-id="${id}"]`);
    if (!item) return;
    
    // Check if already in edit mode
    const existingContainer = item.querySelector('.gp-edit-container');
    if (existingContainer) {
        // Already in edit mode - cancel instead
        cancelGradPkgEdit(id);
        return;
    }
    
    const price = item.dataset.price;
    const desc = item.dataset.desc || '';
    const display = item.querySelector('.gp-display');
    const editBtn = item.querySelector('.btn-edit-price');
    const deleteBtn = item.querySelector('.btn-delete');
    
    // Create container for price and description editing - wrap both vertically
    const editContainer = document.createElement('div');
    editContainer.className = 'gp-edit-container';
    editContainer.style.cssText = 'display:flex;flex-direction:column;gap:8px;grid-column:2/3';
    
    // Create price input
    const priceInput = document.createElement('input');
    priceInput.type = 'number';
    priceInput.className = 'gp-edit-input';
    priceInput.value = price;
    priceInput.step = '50000';
    priceInput.style.cssText = 'border:2px solid var(--accent);padding:6px 8px;border-radius:3px;font-size:13px;font-weight:600;min-width:100px;text-align:right';
    priceInput.placeholder = 'Harga...';
    
    // Create description input
    const descInput = document.createElement('textarea');
    descInput.className = 'gp-edit-desc';
    descInput.value = desc;
    descInput.style.cssText = 'border:2px solid var(--accent);padding:6px 8px;border-radius:3px;font-size:12px;min-width:220px;min-height:135px;font-family:inherit;resize:vertical';
    descInput.placeholder = 'Deskripsi paket (opsional)...';
    
    editContainer.appendChild(priceInput);
    editContainer.appendChild(descInput);
    
    // Replace display with container
    display.replaceWith(editContainer);
    
    // Update button
    editBtn.textContent = '✓';
    editBtn.dataset.editState = 'save';
    editBtn.style.cssText = 'padding:4px 8px;font-size:11px;background:#4caf50;color:white;border:none;cursor:pointer;align-self:flex-start';
    editBtn.onclick = () => saveGradPkgEdit(id);
    
    // Replace delete button onclick with cancel (keep the button, just change behavior)
    deleteBtn.style.cssText = 'padding:4px 8px;font-size:11px;cursor:pointer;align-self:flex-start;background:#f44336;color:white';
    deleteBtn.textContent = '✕';
    deleteBtn.onclick = () => cancelGradPkgEdit(id);
    
    // Focus price input
    priceInput.focus();
    priceInput.select();
}

function saveGradPkgEdit(id) {
    const item = document.querySelector(`.grad-pkg-item[data-id="${id}"]`);
    if (!item) {
        showToast('Error: tidak bisa menemukan paket', 'error');
        return;
    }
    
    // Get container (always exists when in edit mode)
    const container = item.querySelector('.gp-edit-container');
    if (!container) {
        showToast('Error: tidak dalam mode edit', 'error');
        return;
    }
    
    const priceInput = container.querySelector('.gp-edit-input');
    const descInput = container.querySelector('.gp-edit-desc');
    const newPrice = parseInt(priceInput.value || 0);
    const newDesc = descInput.value.trim();
    
    if (newPrice <= 0) {
        showToast('Harga harus lebih dari 0', 'warning');
        priceInput.focus();
        return;
    }
    
    // Update data attributes
    item.dataset.price = newPrice;
    item.dataset.desc = newDesc;
    
    // Update GRAD object
    const pkg = GRAD.packages.find(p => p.id === id);
    if (pkg) {
        pkg.price = newPrice;
        pkg.desc = newDesc;
    }
    
    // Call saveGrad and refresh page setelah save berhasil
    saveGrad().then(() => {
        showToast('✓ Harga & deskripsi paket diperbarui', 'success');
        // Refresh page setelah 1 detik
        setTimeout(() => {
            location.reload();
        }, 1000);
    }).catch(err => {
        showToast('Error saat menyimpan: ' + err, 'error');
        // Tetap restore UI walaupun error
        const display = document.createElement('div');
        display.className = 'gp-display';
        display.style.cssText = 'font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0';
        display.textContent = 'Rp ' + newPrice.toLocaleString('id-ID');
        display.onclick = () => editGradPkg(id);
        
        container.replaceWith(display);
        
        const editBtn = item.querySelector('.btn-edit-price');
        const deleteBtn = item.querySelector('.btn-delete');
        
        if (editBtn) {
            editBtn.textContent = '✏️';
            editBtn.style.cssText = 'padding:4px 8px;font-size:11px;cursor:pointer';
            editBtn.onclick = null;
        }
        
        if (deleteBtn) {
            deleteBtn.style.cssText = 'padding:4px 8px;font-size:11px;cursor:pointer';
            deleteBtn.onclick = () => deleteGradPkg(id);
        }
    });
}

function toggleGradPkgDesc(id) {
    const item = document.querySelector(`.grad-pkg-item[data-id="${id}"]`);
    if (!item) return;
    
    const descArea = item.querySelector('.gp-desc-area');
    const toggleBtn = item.querySelector('.gp-toggle-desc');
    
    if (descArea.style.display === 'none') {
        descArea.style.display = 'block';
        if (toggleBtn) toggleBtn.style.display = 'none';
    } else {
        descArea.style.display = 'none';
        if (toggleBtn) toggleBtn.style.display = 'block';
    }
}

function editDescGradPkg(id) {
    const item = document.querySelector(`.grad-pkg-item[data-id="${id}"]`);
    if (!item) return;
    
    const name = item.dataset.name;
    const currentDesc = item.dataset.desc || '';
    
    // Create modal for editing
    const modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);z-index:2000;display:flex;align-items:center;justify-content:center';
    modal.id = 'desc-edit-modal';
    
    const content = document.createElement('div');
    content.style.cssText = 'background:white;padding:20px;border-radius:8px;max-width:600px;width:90%;max-height:80vh;overflow-y:auto;box-shadow:0 4px 20px rgba(0,0,0,0.2)';
    
    content.innerHTML = `
        <div style="font-size:16px;font-weight:600;margin-bottom:12px">Edit Deskripsi: ${escapeHtml(name)}</div>
        <div style="margin-bottom:12px">
            <label style="font-size:12px;font-weight:600;color:var(--text2);display:block;margin-bottom:6px">Deskripsi Paket</label>
            <textarea id="modal-desc-text" style="width:100%;min-height:100px;border:1px solid var(--border);padding:8px;border-radius:3px;font-size:13px;font-family:inherit;resize:vertical">${escapeHtml(currentDesc)}</textarea>
        </div>
        <div style="display:flex;gap:8px;justify-content:flex-end">
            <button class="btn bs" style="padding:8px 16px;cursor:pointer" onclick="closeDescModal()">Batal</button>
            <button class="btn bp" style="padding:8px 16px;cursor:pointer;background:#2a6b8a;color:white;border:none" onclick="saveDescModal('${escapeHtml(id)}')">💾 Simpan</button>
        </div>
    `;
    
    modal.appendChild(content);
    document.body.appendChild(modal);
    
    // Focus textarea
    document.getElementById('modal-desc-text').focus();
}

function closeDescModal() {
    const modal = document.getElementById('desc-edit-modal');
    if (modal) modal.remove();
}

function saveDescModal(id) {
    const item = document.querySelector(`.grad-pkg-item[data-id="${id}"]`);
    if (!item) return closeDescModal();
    
    const textarea = document.getElementById('modal-desc-text');
    const newDesc = textarea.value.trim();
    
    // Update data attribute
    item.dataset.desc = newDesc;
    
    // Update/rebuild description area
    let descAreaHtml = '';
    if (newDesc) {
        descAreaHtml = `
            <div class="gp-desc-area" style="padding:0 10px 10px 10px;border-top:1px solid var(--border)">
              <div style="font-size:11px;font-weight:600;color:var(--text3);margin-bottom:6px">Deskripsi Paket</div>
              <div style="font-size:12px;line-height:1.4;color:var(--text2);margin-bottom:8px;padding:8px;background:white;border-radius:3px;border:1px solid var(--border)">${escapeHtml(newDesc)}</div>
              <button class="gp-edit-desc-btn" style="width:100%;padding:6px;background:transparent;border:none;border-top:1px solid var(--border);color:var(--text3);font-size:11px;cursor:pointer;text-align:center;margin-top:0" onclick="editDescGradPkg('${escapeHtml(id)}')">✏️ Edit Deskripsi</button>
            </div>
        `;
    } else {
        descAreaHtml = `<button class="gp-add-desc-btn" style="width:100%;padding:6px;background:transparent;border:none;border-top:1px solid var(--border);color:var(--text3);font-size:11px;cursor:pointer;text-align:center;margin-top:0" onclick="editDescGradPkg('${escapeHtml(id)}')">+ Tambah Deskripsi</button>`;
    }
    
    // Remove old description area
    const oldDescArea = item.querySelector('.gp-desc-area');
    const oldAddBtn = item.querySelector('.gp-add-desc-btn');
    const oldEditBtn = item.querySelector('.gp-edit-desc-btn');
    const oldToggleBtn = item.querySelector('.gp-toggle-desc');
    
    if (oldDescArea) oldDescArea.remove();
    if (oldAddBtn) oldAddBtn.remove();
    if (oldEditBtn) oldEditBtn.remove();
    if (oldToggleBtn) oldToggleBtn.remove();
    
    // Add new description area
    const newDescElement = document.createElement('div');
    newDescElement.innerHTML = descAreaHtml;
    item.appendChild(newDescElement.firstElementChild || newDescElement);
    
    showToast('✓ Deskripsi paket disimpan', 'success');
    closeDescModal();
}

function cancelGradPkgEdit(id) {
    const item = document.querySelector(`.grad-pkg-item[data-id="${id}"]`);
    if (!item) return;
    
    const price = item.dataset.price;
    
    const display = document.createElement('div');
    display.className = 'gp-display';
    display.style.cssText = 'font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0';
    display.textContent = 'Rp ' + parseInt(price).toLocaleString('id-ID');
    display.onclick = () => editGradPkg(id);
    
    const container = item.querySelector('.gp-edit-container');
    container.replaceWith(display);
    
    const editBtn = item.querySelector('.btn-edit-price');
    if (editBtn) {
        editBtn.textContent = '✏️';
        editBtn.style.cssText = 'padding:4px 8px;font-size:11px;cursor:pointer';
        editBtn.dataset.editState = '';
        editBtn.onclick = null;
    }
    
    const deleteBtn = item.querySelector('.btn-delete');
    if (deleteBtn) {
        deleteBtn.style.cssText = 'padding:4px 8px;font-size:11px;cursor:pointer';
        deleteBtn.textContent = '✕';
        deleteBtn.onclick = () => deleteGradPkg(id);
    }
}

function addGradPkg() {
    const name = document.getElementById('new-grad-pkg-name').value.trim();
    const price = parseInt(document.getElementById('new-grad-pkg-price').value || 0);
    const desc = document.getElementById('new-grad-pkg-desc').value.trim();
    
    if (!name) {
        showToast('Nama paket tidak boleh kosong', 'warning');
        return;
    }
    
    if (price <= 0) {
        showToast('Harga harus lebih dari 0', 'warning');
        return;
    }
    
    // Generate ID from timestamp
    const id = 'gp_' + Date.now();
    
    // Check if package already exists
    const existing = document.querySelector(`.grad-pkg-item[data-name="${name}"]`);
    if (existing) {
        showToast('Paket "' + name + '" sudah ada', 'warning');
        return;
    }
    
    // Create new item element
    const newItem = document.createElement('div');
    newItem.className = 'grad-pkg-item';
    newItem.dataset.id = id;
    newItem.dataset.name = name;
    newItem.dataset.price = price;
    newItem.dataset.desc = desc;
    newItem.style.cssText = 'margin-bottom:8px;padding:10px;background:#fafafa;border-radius:4px;border:1px solid var(--border);display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center';
    
    // Create grid content
    newItem.innerHTML = `
        <div style="font-size:13px;font-weight:500">${escapeHtml(name)}</div>
        <div class="gp-display" style="font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0" onclick="editGradPkg('${escapeHtml(id)}')">Rp ${price.toLocaleString('id-ID')}</div>
        <button class="btn bs bsm btn-edit-price" data-id="${escapeHtml(id)}" style="padding:4px 8px;font-size:11px;cursor:pointer">✏️</button>
        <button class="btn bs bsm btn-delete" data-id="${escapeHtml(id)}" style="padding:4px 8px;font-size:11px;cursor:pointer">✕</button>
    `;
    
    document.getElementById('grad-pkg-items').appendChild(newItem);
    
    // Attach event listeners to new buttons
    const editBtn = newItem.querySelector('.btn-edit-price');
    const deleteBtn = newItem.querySelector('.btn-delete');
    
    editBtn.addEventListener('click', function() {
        editGradPkg(this.dataset.id);
    });
    deleteBtn.addEventListener('click', function() {
        deleteGradPkg(this.dataset.id);
    });
    
    // Clear form
    document.getElementById('new-grad-pkg-name').value = '';
    document.getElementById('new-grad-pkg-price').value = '';
    document.getElementById('new-grad-pkg-desc').value = '';
    
    // Add to GRAD object
    GRAD.packages.push({
        id: id,
        name: name,
        price: price,
        desc: desc,
        color: '#A9D6E5'
    });
    
    showToast('✓ Paket "' + name + '" ditambahkan', 'success');
}

function deleteGradPkg(id) {
    const item = document.querySelector(`.grad-pkg-item[data-id="${id}"]`);
    if (!item) return;
    
    const name = item.dataset.name;
    
    // Animate removal
    item.style.opacity = '0.5';
    item.style.textDecoration = 'line-through';
    
    setTimeout(() => {
        item.remove();
        showToast('✓ Paket "' + name + '" dihapus', 'success');
        // Auto-save after delete
        saveGrad();
    }, 300);
}

// ===== GRADIENT ADD-ON CRUD =====

async function saveGradAddon() {
    // Collect addon and cetak prices from data attributes
    const addons = [];
    document.querySelectorAll('.grad-addon-item').forEach(item => {
        addons.push({
            id: item.dataset.id,
            name: item.dataset.name,
            price: parseInt(item.dataset.price || 0)
        });
    });
    
    const cetak = [];
    document.querySelectorAll('.grad-cetak-item').forEach(item => {
        cetak.push({
            id: item.dataset.id,
            name: item.dataset.name,
            price: parseInt(item.dataset.price || 0)
        });
    });
    
    GRAD.addons = addons;
    GRAD.cetak = cetak;
    
    const success = await updateMasterData('graduation', GRAD);
    if (success) {
        renderGraduation();
        showToast('✓ Add-on & Cetak berhasil tersimpan', 'success');
    } else {
        showToast('✕ Gagal menyimpan add-on & cetak', 'error');
    }
}

function editGradAddon(id) {
    const item = document.querySelector(`.grad-addon-item[data-id="${id}"]`);
    if (!item) return;
    
    const price = item.dataset.price;
    const display = item.querySelector('.ga-display');
    const editBtn = item.querySelector('button:nth-child(3)');
    
    // Hide display, show edit mode
    const input = document.createElement('input');
    input.type = 'number';
    input.className = 'ga-edit-input';
    input.value = price;
    input.step = '50000';
    input.style.cssText = 'border:2px solid var(--accent);padding:6px 8px;border-radius:3px;font-size:13px;font-weight:600;width:120px;text-align:right';
    
    // Replace display with input
    display.replaceWith(input);
    editBtn.textContent = '✓';
    editBtn.onclick = () => saveGradAddonEdit(id);
    editBtn.style.cssText = 'padding:4px 8px;font-size:11px;background:#4caf50;color:white;border:none;cursor:pointer';
    
    // Replace delete button with cancel
    const deleteBtn = item.querySelector('button:nth-child(4)');
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'btn bs bsm';
    cancelBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    cancelBtn.textContent = '✕';
    cancelBtn.onclick = () => cancelGradAddonEdit(id);
    deleteBtn.replaceWith(cancelBtn);
    
    // Focus input
    input.focus();
    input.select();
}

function saveGradAddonEdit(id) {
    const item = document.querySelector(`.grad-addon-item[data-id="${id}"]`);
    if (!item) return;
    
    const input = item.querySelector('.ga-edit-input');
    const newPrice = parseInt(input.value || 0);
    
    if (newPrice <= 0) {
        showToast('Harga harus lebih dari 0', 'warning');
        input.focus();
        return;
    }
    
    // Update data and display
    item.dataset.price = newPrice;
    
    const display = document.createElement('div');
    display.className = 'ga-display';
    display.style.cssText = 'font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0';
    display.textContent = 'Rp ' + newPrice.toLocaleString('id-ID');
    display.onclick = () => editGradAddon(id);
    
    const editBtn = item.querySelector('button:nth-child(3)');
    const cancelBtn = item.querySelector('button:nth-child(4)');
    
    // Restore buttons
    input.replaceWith(display);
    editBtn.textContent = '✏️';
    editBtn.onclick = () => editGradAddon(id);
    editBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn bs bsm';
    deleteBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    deleteBtn.textContent = '✕';
    deleteBtn.onclick = () => deleteGradAddon(id);
    cancelBtn.replaceWith(deleteBtn);
    
    showToast('✓ Add-on diperbarui', 'success');
}

function cancelGradAddonEdit(id) {
    const item = document.querySelector(`.grad-addon-item[data-id="${id}"]`);
    if (!item) return;
    
    const price = item.dataset.price;
    
    const display = document.createElement('div');
    display.className = 'ga-display';
    display.style.cssText = 'font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0';
    display.textContent = 'Rp ' + parseInt(price).toLocaleString('id-ID');
    display.onclick = () => editGradAddon(id);
    
    const input = item.querySelector('.ga-edit-input');
    input.replaceWith(display);
    
    const editBtn = item.querySelector('button:nth-child(3)');
    editBtn.textContent = '✏️';
    editBtn.onclick = () => editGradAddon(id);
    editBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    
    const cancelBtn = item.querySelector('button:nth-child(4)');
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn bs bsm';
    deleteBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    deleteBtn.textContent = '✕';
    deleteBtn.onclick = () => deleteGradAddon(id);
    cancelBtn.replaceWith(deleteBtn);
}

function addGradAddon() {
    const name = document.getElementById('new-grad-addon-name').value.trim();
    const price = parseInt(document.getElementById('new-grad-addon-price').value || 0);
    
    if (!name) {
        showToast('Nama add-on tidak boleh kosong', 'warning');
        return;
    }
    
    if (price <= 0) {
        showToast('Harga harus lebih dari 0', 'warning');
        return;
    }
    
    // Generate ID from name
    const id = 'ga_' + Date.now();
    
    // Check if item already exists
    const existing = document.querySelector(`.grad-addon-item[data-name="${name}"]`);
    if (existing) {
        showToast('Add-on "' + name + '" sudah ada', 'warning');
        return;
    }
    
    // Create new item element
    const newItem = document.createElement('div');
    newItem.className = 'grad-addon-item';
    newItem.dataset.id = id;
    newItem.dataset.name = name;
    newItem.dataset.price = price;
    newItem.style.cssText = 'display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center;margin-bottom:8px;padding:10px;background:#fafafa;border-radius:4px';
    
    newItem.innerHTML = `
        <div style="font-size:13px;font-weight:500">${escapeHtml(name)}</div>
        <div class="ga-display" style="font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0" onclick="editGradAddon('${escapeHtml(id)}')">Rp ${price.toLocaleString('id-ID')}</div>
        <button class="btn bs bsm" onclick="editGradAddon('${escapeHtml(id)}')" style="padding:4px 8px;font-size:11px">✏️</button>
        <button class="btn bs bsm" onclick="deleteGradAddon('${escapeHtml(id)}')" style="padding:4px 8px;font-size:11px">✕</button>
    `;
    
    document.getElementById('grad-addon-items').appendChild(newItem);
    
    // Clear form
    document.getElementById('new-grad-addon-name').value = '';
    document.getElementById('new-grad-addon-price').value = '';
    
    showToast('✓ Add-on "' + name + '" ditambahkan', 'success');
}

function deleteGradAddon(id) {
    const item = document.querySelector(`.grad-addon-item[data-id="${id}"]`);
    if (!item) return;
    
    const name = item.dataset.name;
    
    // Animate removal
    item.style.opacity = '0.5';
    item.style.textDecoration = 'line-through';
    
    setTimeout(() => {
        item.remove();
        showToast('✓ Add-on "' + name + '" dihapus', 'success');
        // Auto-save after delete
        saveGradAddon();
    }, 300);
}

// ===== GRADUATION CETAK CRUD =====

function editGradCetak(id) {
    const item = document.querySelector(`.grad-cetak-item[data-id="${id}"]`);
    if (!item) return;
    
    const price = item.dataset.price;
    const display = item.querySelector('.gc-display');
    const editBtn = item.querySelector('button:nth-child(3)');
    
    // Hide display, show edit mode
    const input = document.createElement('input');
    input.type = 'number';
    input.className = 'gc-edit-input';
    input.value = price;
    input.step = '500';
    input.style.cssText = 'border:2px solid var(--accent);padding:6px 8px;border-radius:3px;font-size:13px;font-weight:600;width:120px;text-align:right';
    
    // Replace display with input
    display.replaceWith(input);
    editBtn.textContent = '✓';
    editBtn.onclick = () => saveGradCetakEdit(id);
    editBtn.style.cssText = 'padding:4px 8px;font-size:11px;background:#4caf50;color:white;border:none;cursor:pointer';
    
    // Replace delete button with cancel
    const deleteBtn = item.querySelector('button:nth-child(4)');
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'btn bs bsm';
    cancelBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    cancelBtn.textContent = '✕';
    cancelBtn.onclick = () => cancelGradCetakEdit(id);
    deleteBtn.replaceWith(cancelBtn);
    
    // Focus input
    input.focus();
    input.select();
}

function saveGradCetakEdit(id) {
    const item = document.querySelector(`.grad-cetak-item[data-id="${id}"]`);
    if (!item) return;
    
    const input = item.querySelector('.gc-edit-input');
    const newPrice = parseInt(input.value || 0);
    
    if (newPrice <= 0) {
        showToast('Harga harus lebih dari 0', 'warning');
        input.focus();
        return;
    }
    
    // Update data and display
    item.dataset.price = newPrice;
    
    const display = document.createElement('div');
    display.className = 'gc-display';
    display.style.cssText = 'font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0';
    display.textContent = 'Rp ' + newPrice.toLocaleString('id-ID');
    display.onclick = () => editGradCetak(id);
    
    const editBtn = item.querySelector('button:nth-child(3)');
    const cancelBtn = item.querySelector('button:nth-child(4)');
    
    // Restore buttons
    input.replaceWith(display);
    editBtn.textContent = '✏️';
    editBtn.onclick = () => editGradCetak(id);
    editBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn bs bsm';
    deleteBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    deleteBtn.textContent = '✕';
    deleteBtn.onclick = () => deleteGradCetak(id);
    cancelBtn.replaceWith(deleteBtn);
    
    showToast('✓ Cetak foto diperbarui', 'success');
}

function cancelGradCetakEdit(id) {
    const item = document.querySelector(`.grad-cetak-item[data-id="${id}"]`);
    if (!item) return;
    
    const price = item.dataset.price;
    
    const display = document.createElement('div');
    display.className = 'gc-display';
    display.style.cssText = 'font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0';
    display.textContent = 'Rp ' + parseInt(price).toLocaleString('id-ID');
    display.onclick = () => editGradCetak(id);
    
    const input = item.querySelector('.gc-edit-input');
    input.replaceWith(display);
    
    const editBtn = item.querySelector('button:nth-child(3)');
    editBtn.textContent = '✏️';
    editBtn.onclick = () => editGradCetak(id);
    editBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    
    const cancelBtn = item.querySelector('button:nth-child(4)');
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn bs bsm';
    deleteBtn.style.cssText = 'padding:4px 8px;font-size:11px';
    deleteBtn.textContent = '✕';
    deleteBtn.onclick = () => deleteGradCetak(id);
    cancelBtn.replaceWith(deleteBtn);
}

function addGradCetak() {
    const name = document.getElementById('new-grad-cetak-name').value.trim();
    const price = parseInt(document.getElementById('new-grad-cetak-price').value || 0);
    
    if (!name) {
        showToast('Nama cetak tidak boleh kosong', 'warning');
        return;
    }
    
    if (price <= 0) {
        showToast('Harga harus lebih dari 0', 'warning');
        return;
    }
    
    // Generate ID from name
    const id = 'gc_' + Date.now();
    
    // Check if item already exists
    const existing = document.querySelector(`.grad-cetak-item[data-name="${name}"]`);
    if (existing) {
        showToast('Cetak "' + name + '" sudah ada', 'warning');
        return;
    }
    
    // Create new item element
    const newItem = document.createElement('div');
    newItem.className = 'grad-cetak-item';
    newItem.dataset.id = id;
    newItem.dataset.name = name;
    newItem.dataset.price = price;
    newItem.style.cssText = 'display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center;margin-bottom:8px;padding:10px;background:#fafafa;border-radius:4px';
    
    newItem.innerHTML = `
        <div style="font-size:13px;font-weight:500">${escapeHtml(name)}</div>
        <div class="gc-display" style="font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0" onclick="editGradCetak('${escapeHtml(id)}')">Rp ${price.toLocaleString('id-ID')}</div>
        <button class="btn bs bsm" onclick="editGradCetak('${escapeHtml(id)}')" style="padding:4px 8px;font-size:11px">✏️</button>
        <button class="btn bs bsm" onclick="deleteGradCetak('${escapeHtml(id)}')" style="padding:4px 8px;font-size:11px">✕</button>
    `;
    
    document.getElementById('grad-cetak-items').appendChild(newItem);
    
    // Clear form
    document.getElementById('new-grad-cetak-name').value = '';
    document.getElementById('new-grad-cetak-price').value = '';
    
    showToast('✓ Cetak "' + name + '" ditambahkan', 'success');
}

function deleteGradCetak(id) {
    const item = document.querySelector(`.grad-cetak-item[data-id="${id}"]`);
    if (!item) return;
    
    const name = item.dataset.name;
    
    // Animate removal
    item.style.opacity = '0.5';
    item.style.textDecoration = 'line-through';
    
    setTimeout(() => {
        item.remove();
        showToast('✓ Cetak "' + name + '" dihapus', 'success');
        // Auto-save after delete
        saveGradAddon();
    }, 300);
}

async function resetGrad() {
    showToast('⏳ Memproses reset...', 'info');
    GRAD = {
        packages: [
            {id:'gphv',name:'Photo & Video',price:4500000,desc:'2 Fotografer + 1 Videografer, 50 foto edited, video cinematic 2–4 mnt, G-Drive, 4 jam coverage, transport jabodetabek',color:'acc'},
            {id:'gvideo',name:'Video Only',price:2000000,desc:'1 Videografer, video cinematic 2–5 mnt, G-Drive, 4 jam coverage, transport jabodetabek',color:''},
            {id:'gphoto',name:'Photo Only',price:2750000,desc:'2 Fotografer, 100 foto edited, G-Drive, 4 jam coverage, transport jabodetabek',color:''},
            {id:'gbooth',name:'Photo Booth',price:3850000,desc:'1–2 Crew profesional, backdrop wisuda, lighting studio, Selfiebox Machine, unlimited print 4R, max 3 jam, softcopy + QR Code realtime, transport jabodetabek',color:''},
            {id:'g360',name:'Glamation 360°',price:4100000,desc:'1–2 Crew profesional, MP4, LCD 50in preview, GoPro/iPhone 12 Pro, overlay design free, max 3 jam, QR Code realtime, transport jabodetabek',color:''},
            {id:'gcomplete',name:'Complete Package',price:7750000,desc:'Photo (2 foto, 100 edited) + Video (1 videografer, cinematic 2–4 mnt) + Photo Booth (unlimited print 4R, max 3 jam, QR Code), transport jabodetabek',color:'feat'},
        ],
        addons: [
            {id:'gvideo_add',name:'Tambah 1 Videografer',price:1500000},
            {id:'gphoto_add',name:'Tambah 1 Fotografer',price:1250000},
            {id:'gbooth_add',name:'Tambah 1 Jam Photobooth/360',price:500000},
            {id:'gwork_add',name:'Tambah 1 Jam Kerja/Orang',price:350000},
        ],
        cetak: [
            {id:'g4r',name:'Cetak Foto 4R',price:4000},
            {id:'g8r',name:'Cetak Foto 8R',price:8000},
            {id:'g10r',name:'Cetak Foto 10R',price:15000},
            {id:'g12r',name:'Cetak Foto 12R',price:20000},
        ]
    };
    
    // Update form fields with reset values - packages
    document.getElementById('grad-pkg-items').innerHTML = '';
    GRAD.packages.forEach(pkg => {
        const newItem = document.createElement('div');
        newItem.className = 'grad-pkg-item';
        newItem.dataset.id = pkg.id;
        newItem.dataset.name = pkg.name;
        newItem.dataset.price = pkg.price;
        newItem.dataset.desc = pkg.desc || '';
        newItem.style.cssText = 'margin-bottom:12px;padding:0;background:#fafafa;border-radius:4px;border:1px solid var(--border)';
        
        let descBottom = '';
        if (pkg.desc) {
            descBottom = `
                <div class="gp-desc-area" style="padding:0 10px 10px 10px;border-top:1px solid var(--border)">
                  <div style="font-size:11px;font-weight:600;color:var(--text3);margin-bottom:6px">Deskripsi Paket</div>
                  <div style="font-size:12px;line-height:1.4;color:var(--text2);margin-bottom:8px;padding:8px;background:white;border-radius:3px;border:1px solid var(--border)">${escapeHtml(pkg.desc)}</div>
                  <button class="gp-edit-desc-btn" style="width:100%;padding:6px;background:transparent;border:none;border-top:1px solid var(--border);color:var(--text3);font-size:11px;cursor:pointer;text-align:center;margin-top:0" onclick="editDescGradPkg('${escapeHtml(pkg.id)}')">✏️ Edit Deskripsi</button>
                </div>
            `;
        } else {
            descBottom = `<button class="gp-add-desc-btn" style="width:100%;padding:6px;background:transparent;border:none;border-top:1px solid var(--border);color:var(--text3);font-size:11px;cursor:pointer;text-align:center;margin-top:0" onclick="editDescGradPkg('${escapeHtml(pkg.id)}')">+ Tambah Deskripsi</button>`;
        }
        
        newItem.innerHTML = `
            <div style="display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center;padding:10px">
              <div style="font-size:13px;font-weight:500">${escapeHtml(pkg.name)}</div>
              <div class="gp-display" style="font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0" onclick="editGradPkg('${escapeHtml(pkg.id)}')">Rp ${pkg.price.toLocaleString('id-ID')}</div>
              <button class="btn bs bsm" onclick="editGradPkg('${escapeHtml(pkg.id)}')" style="padding:4px 8px;font-size:11px">✏️</button>
              <button class="btn bs bsm" onclick="deleteGradPkg('${escapeHtml(pkg.id)}')" style="padding:4px 8px;font-size:11px">✕</button>
            </div>
            ${descBottom}
        `;
        
        document.getElementById('grad-pkg-items').appendChild(newItem);
    });
    
    // Update form fields with reset values - addons
    document.getElementById('grad-addon-items').innerHTML = '';
    GRAD.addons.forEach(addon => {
        const newItem = document.createElement('div');
        newItem.className = 'grad-addon-item';
        newItem.dataset.id = addon.id;
        newItem.dataset.name = addon.name;
        newItem.dataset.price = addon.price;
        newItem.style.cssText = 'display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center;margin-bottom:8px;padding:10px;background:#fafafa;border-radius:4px';
        
        newItem.innerHTML = `
            <div style="font-size:13px;font-weight:500">${escapeHtml(addon.name)}</div>
            <div class="ga-display" style="font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0" onclick="editGradAddon('${escapeHtml(addon.id)}')">Rp ${addon.price.toLocaleString('id-ID')}</div>
            <button class="btn bs bsm" onclick="editGradAddon('${escapeHtml(addon.id)}')" style="padding:4px 8px;font-size:11px">✏️</button>
            <button class="btn bs bsm" onclick="deleteGradAddon('${escapeHtml(addon.id)}')" style="padding:4px 8px;font-size:11px">✕</button>
        `;
        
        document.getElementById('grad-addon-items').appendChild(newItem);
    });
    
    // Update form fields with reset values - cetak
    document.getElementById('grad-cetak-items').innerHTML = '';
    GRAD.cetak.forEach(cetak => {
        const newItem = document.createElement('div');
        newItem.className = 'grad-cetak-item';
        newItem.dataset.id = cetak.id;
        newItem.dataset.name = cetak.name;
        newItem.dataset.price = cetak.price;
        newItem.style.cssText = 'display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center;margin-bottom:8px;padding:10px;background:#fafafa;border-radius:4px';
        
        newItem.innerHTML = `
            <div style="font-size:13px;font-weight:500">${escapeHtml(cetak.name)}</div>
            <div class="gc-display" style="font-size:13px;font-weight:600;color:var(--accent);min-width:120px;text-align:right;cursor:pointer;padding:4px 0" onclick="editGradCetak('${escapeHtml(cetak.id)}')">Rp ${cetak.price.toLocaleString('id-ID')}</div>
            <button class="btn bs bsm" onclick="editGradCetak('${escapeHtml(cetak.id)}')" style="padding:4px 8px;font-size:11px">✏️</button>
            <button class="btn bs bsm" onclick="deleteGradCetak('${escapeHtml(cetak.id)}')" style="padding:4px 8px;font-size:11px">✕</button>
        `;
        
        document.getElementById('grad-cetak-items').appendChild(newItem);
    });
    
    renderGraduation();
    await saveGradAddon();
}

// ============================================================
// PAYMENT TERMS CRUD FUNCTIONS
// ============================================================

// Global Payment Terms object
let PT = <?= json_encode(['terms' => $paymentTerms]) ?>;

async function savePaymentTerms() {
    try {
        // Collect payment terms from data attributes
        const terms = [];
        document.querySelectorAll('.pt-item').forEach(item => {
            terms.push({
                id: item.dataset.id,
                name: item.dataset.name,
                deposit: parseInt(item.dataset.deposit || 0),
                desc: item.dataset.desc || '',
                color: item.dataset.color || '#9B59B6'
            });
        });
        
        console.log('Collected terms:', terms);
        console.log('MASTER_API defined?', typeof MASTER_API !== 'undefined', MASTER_API);
        
        // Update PT object and save
        PT.terms = terms;
        
        console.log('PT object to be saved:', PT);
        console.log('updateMasterData function exists?', typeof updateMasterData === 'function');
        
        const success = await updateMasterData('payment_terms', PT);
        console.log('updateMasterData result:', success);
        
        if (success) {
            showToast('✓ Syarat Pembayaran berhasil tersimpan', 'success');
            console.log('Reloading page in 500ms...');
            setTimeout(() => {
                location.reload();
            }, 500);
        } else {
            showToast('✕ Gagal menyimpan syarat pembayaran', 'error');
        }
    } catch (err) {
        console.error('Error in savePaymentTerms:', err);
        console.error('Stack:', err.stack);
        showToast('✕ Error: ' + err.message, 'error');
    }
}

function editPaymentTerm(id) {
    try {
        const item = document.querySelector(`.pt-item[data-id="${id}"]`);
        if (!item) {
            showToast('✕ Error: Item tidak ditemukan', 'error');
            console.error('Item not found for PT id:', id);
            return;
        }
        
        // Check if already in edit mode
        const existingContainer = item.querySelector('.pt-edit-container');
        if (existingContainer) {
            cancelPaymentTermEdit(id);
            return;
        }
        
        const name = item.dataset.name;
        const deposit = item.dataset.deposit || '';
        const desc = item.dataset.desc || '';
        const color = item.dataset.color || '#9B59B6';
        
        console.log('editPaymentTerm started for id:', id, { name, deposit, desc, color });
        
        // Find the details div - it contains name (font-weight:600) and DP info (text3 color)
        let detailsDiv = null;
        const allDivs = item.querySelectorAll('div');
        console.log('Total divs in item:', allDivs.length);
        
        for (let el of allDivs) {
            const hasName = el.querySelector('[style*="font-weight:600"]');
            const hasDP = el.textContent.includes('DP:');
            if (hasName && hasDP) {
                detailsDiv = el;
                console.log('Found details div');
                break;
            }
        }
        
        if (!detailsDiv) {
            showToast('✕ Error: Detail area tidak ditemukan', 'error');
            console.error('Details div not found');
            return;
        }
        
        // Create container for editing
        const editContainer = document.createElement('div');
        editContainer.className = 'pt-edit-container';
        editContainer.style.cssText = 'display:flex;flex-direction:column;gap:8px';
        
        // Create inputs
        const nameInput = document.createElement('input');
        nameInput.type = 'text';
        nameInput.className = 'pt-edit-name';
        nameInput.value = name;
        nameInput.placeholder = 'Nama';
        nameInput.style.cssText = 'border:2px solid #9B59B6;padding:6px 8px;border-radius:3px;font-size:12px;font-weight:600';
        
        const depositInput = document.createElement('input');
        depositInput.type = 'number';
        depositInput.className = 'pt-edit-deposit';
        depositInput.value = deposit;
        depositInput.min = 0;
        depositInput.max = 100;
        depositInput.placeholder = 'DP %';
        depositInput.style.cssText = 'border:2px solid #9B59B6;padding:6px 8px;border-radius:3px;font-size:12px;text-align:center;width:60px';
        
        const descInput = document.createElement('textarea');
        descInput.className = 'pt-edit-desc';
        descInput.value = desc;
        descInput.placeholder = 'Deskripsi...';
        descInput.style.cssText = 'border:2px solid #9B59B6;padding:6px 8px;border-radius:3px;font-size:12px;font-family:inherit;min-height:60px;resize:vertical';
        
        const colorInput = document.createElement('input');
        colorInput.type = 'color';
        colorInput.className = 'pt-edit-color';
        colorInput.value = color;
        colorInput.style.cssText = 'border:2px solid #9B59B6;padding:2px;border-radius:3px;height:32px;cursor:pointer;width:60px';
        
        // Create wrapper for Name + Color in one row
        const nameColorWrapper = document.createElement('div');
        nameColorWrapper.style.cssText = 'display:grid;grid-template-columns:1fr 60px;gap:8px;align-items:flex-start';
        nameColorWrapper.appendChild(nameInput);
        nameColorWrapper.appendChild(colorInput);
        
        editContainer.appendChild(nameColorWrapper);
        editContainer.appendChild(descInput);
        editContainer.appendChild(depositInput);
        
        // Replace details display with edit container
        detailsDiv.replaceWith(editContainer);
        console.log('Replaced detailsDiv with editContainer');
        
        // Update buttons
        const editBtn = item.querySelector('.btn-edit-pt');
        const deleteBtn = item.querySelector('.btn-delete-pt');
        
        console.log('Found buttons - edit:', !!editBtn, 'delete:', !!deleteBtn);
        
        if (editBtn) {
            editBtn.textContent = '✓';
            editBtn.style.cssText = 'padding:4px 8px;font-size:11px;background:#2ECC71;color:white;border:none;cursor:pointer';
            editBtn.onclick = function() { savePaymentTermEdit(id); };
        }
        
        if (deleteBtn) {
            deleteBtn.style.cssText = 'padding:4px 8px;font-size:11px;background:#E74C3C;color:white;border:none;cursor:pointer';
            deleteBtn.onclick = function() { cancelPaymentTermEdit(id); };
        }
        
        // Focus name input
        nameInput.focus();
        nameInput.select();
        console.log('editPaymentTerm completed successfully');
    } catch (err) {
        console.error('Error in editPaymentTerm:', err);
        showToast('✕ Error: ' + err.message, 'error');
    }
}

async function savePaymentTermEdit(id) {
    try {
        console.log('savePaymentTermEdit called for id:', id);
        
        const item = document.querySelector(`.pt-item[data-id="${id}"]`);
        if (!item) {
            console.error('Item not found');
            showToast('✕ Error: Item tidak ditemukan', 'error');
            return;
        }
        
        const container = item.querySelector('.pt-edit-container');
        if (!container) {
            console.error('Edit container not found');
            showToast('✕ Error: Edit mode tidak aktif', 'error');
            return;
        }
        
        const nameInput = container.querySelector('.pt-edit-name');
        const depositInput = container.querySelector('.pt-edit-deposit');
        const descInput = container.querySelector('.pt-edit-desc');
        const colorInput = container.querySelector('.pt-edit-color');
        
        const newName = nameInput.value.trim();
        const newDeposit = parseInt(depositInput.value.trim());
        const newDesc = descInput.value.trim();
        const newColor = colorInput.value;
        
        console.log('New values:', { newName, newDeposit, newDesc, newColor });
        
        if (!newName) {
            showToast('✕ Nama tidak boleh kosong', 'error');
            nameInput.focus();
            return;
        }
        if (isNaN(newDeposit) || newDeposit < 0 || newDeposit > 100) {
            showToast('✕ Deposit harus berupa angka antara 0-100', 'error');
            depositInput.focus();
            return;
        }
        
        // Update data attributes
        item.dataset.name = newName;
        item.dataset.deposit = newDeposit;
        item.dataset.desc = newDesc;
        item.dataset.color = newColor;
        
        console.log('Data attributes updated');
        
        // Recreate the entire item HTML to restore clean state
        const newItem = document.createElement('div');
        newItem.className = 'pt-item';
        newItem.dataset.id = id;
        newItem.dataset.name = newName;
        newItem.dataset.deposit = newDeposit;
        newItem.dataset.desc = newDesc;
        newItem.dataset.color = newColor;
        newItem.style.cssText = 'margin-bottom:8px;padding:10px;background:#fafafa;border-radius:4px;border:1px solid var(--border);display:grid;grid-template-columns:auto 1fr auto auto auto;gap:12px;align-items:center';
        
        newItem.innerHTML = `
            <div style="width:20px;height:20px;border-radius:3px;background:${escapeHtml(newColor)};border:1px solid rgba(0,0,0,0.1)"></div>
            <div style="flex:1">
                <div style="font-size:13px;font-weight:600">${escapeHtml(newName)}</div>
                <div style="font-size:11px;color:var(--text3);margin-top:2px">DP: ${escapeHtml(newDeposit)}%</div>
            </div>
            <div style="font-size:12px;color:var(--text2);min-width:200px">${escapeHtml(newDesc) || '—'}</div>
            <button class="btn bs bsm btn-edit-pt" data-id="${escapeHtml(id)}" style="padding:4px 8px;font-size:11px;cursor:pointer">✏️</button>
            <button class="btn bs bsm btn-delete-pt" data-id="${escapeHtml(id)}" style="padding:4px 8px;font-size:11px;cursor:pointer">✕</button>
        `;
        
        // Replace entire item
        item.replaceWith(newItem);
        
        console.log('Item replaced with clean state');
        console.log('savePaymentTermEdit completed');
        
        // Auto-save langsung setelah edit
        await savePaymentTerms();
    } catch (err) {
        console.error('Error in savePaymentTermEdit:', err);
        console.error('Stack:', err.stack);
        showToast('✕ Error: ' + err.message, 'error');
    }
}

function cancelPaymentTermEdit(id) {
    const item = document.querySelector(`.pt-item[data-id="${id}"]`);
    if (!item) return;
    
    const container = item.querySelector('.pt-edit-container');
    if (!container) return;
    
    const name = item.dataset.name;
    const deposit = item.dataset.deposit;
    const desc = item.dataset.desc || '';
    
    // Create new details display div
    const newDetailsDiv = document.createElement('div');
    newDetailsDiv.style.cssText = 'flex:1';
    newDetailsDiv.innerHTML = `
        <div style="font-size:13px;font-weight:600">${escapeHtml(name)}</div>
        <div style="font-size:11px;color:var(--text3);margin-top:2px">DP: ${escapeHtml(deposit)}%</div>
    `;
    
    // Replace edit container with details display
    container.replaceWith(newDetailsDiv);
    
    // Restore buttons
    const editBtn = item.querySelector('.btn-edit-pt');
    const deleteBtn = item.querySelector('.btn-delete-pt');
    
    if (editBtn) {
        editBtn.textContent = '✏️';
        editBtn.style.cssText = 'padding:4px 8px;font-size:11px;cursor:pointer';
        editBtn.onclick = function() { editPaymentTerm(id); };
    }
    
    if (deleteBtn) {
        deleteBtn.style.cssText = 'padding:4px 8px;font-size:11px;cursor:pointer';
        deleteBtn.onclick = function() { deletePaymentTerm(id); };
    }
}

async function deletePaymentTerm(id) {
    if (!confirm('Yakin ingin menghapus syarat pembayaran ini?')) return;
    
    const item = document.querySelector(`.pt-item[data-id="${id}"]`);
    if (item) {
        item.remove();
        await savePaymentTerms();
    }
}

async function addPaymentTerm() {
    const nameInput = document.getElementById('new-pt-name');
    const depositInput = document.getElementById('new-pt-deposit');
    const descInput = document.getElementById('new-pt-desc');
    const colorInput = document.getElementById('new-pt-color');
    
    const name = nameInput.value.trim();
    const deposit = depositInput.value.trim();
    const desc = descInput.value.trim();
    const color = colorInput.value || '#9B59B6';
    
    if (!name) {
        showToast('✕ Nama tidak boleh kosong', 'error');
        return;
    }
    if (!deposit || isNaN(deposit)) {
        showToast('✕ Deposit harus berupa angka', 'error');
        return;
    }
    
    // Generate unique ID
    const id = 'pt_' + Date.now();
    
    // Create new item element
    const newItem = document.createElement('div');
    newItem.className = 'pt-item';
    newItem.dataset.id = id;
    newItem.dataset.name = name;
    newItem.dataset.deposit = deposit;
    newItem.dataset.desc = desc;
    newItem.dataset.color = color;
    newItem.style.cssText = 'margin-bottom:8px;padding:10px;background:#fafafa;border-radius:4px;border:1px solid var(--border);display:grid;grid-template-columns:auto 1fr auto auto auto;gap:12px;align-items:center';
    
    newItem.innerHTML = `
        <div style="width:20px;height:20px;border-radius:3px;background:${escapeHtml(color)};border:1px solid rgba(0,0,0,0.1)"></div>
        <div style="flex:1">
            <div style="font-size:13px;font-weight:600">${escapeHtml(name)}</div>
            <div style="font-size:11px;color:var(--text3);margin-top:2px">DP: ${escapeHtml(deposit)}%</div>
        </div>
        <div style="font-size:12px;color:var(--text2);min-width:200px">${escapeHtml(desc) || '—'}</div>
        <button class="btn bs bsm btn-edit-pt" data-id="${escapeHtml(id)}" style="padding:4px 8px;font-size:11px;cursor:pointer">✏️</button>
        <button class="btn bs bsm btn-delete-pt" data-id="${escapeHtml(id)}" style="padding:4px 8px;font-size:11px;cursor:pointer">✕</button>
    `;
    
    document.getElementById('pt-items').appendChild(newItem);
    
    // Clear form
    nameInput.value = '';
    depositInput.value = '';
    descInput.value = '';
    colorInput.value = '#9B59B6';
    
    // Auto-save setelah tambah
    await savePaymentTerms();
}

function resetPaymentTerms() {
    if (!confirm('Yakin ingin reset ke default? Semua perubahan akan hilang.')) return;
    
    // Reload page to restore defaults
    location.reload();
}

// Initialize Payment Terms - DOMContentLoaded event listener
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOMContentLoaded - Initializing pengaturan page');
    console.log('DB_SETTINGS:', DB_SETTINGS);
    console.log('GRAD:', GRAD);
    console.log('PT:', PT);
    
    // Initialize Overhead total display
    updateOHTotal();
    
    // Render tabel Biaya Cetak (JANGAN panggil renderPengaturan() dari app-pages.js
    // karena ia mengakses elemen ov-oh yang tidak ada di halaman ini)
    if (typeof renderCetakTable === 'function') {
        renderCetakTable();
    }
    
    // Event delegation for package items container
    const pkgItemsContainer = document.getElementById('grad-pkg-items');
    if (pkgItemsContainer) {
        pkgItemsContainer.addEventListener('click', function(e) {
            if (e.target.classList.contains('btn-edit-price')) {
                const id = e.target.dataset.id;
                if (id) {
                    editGradPkg(id);
                }
            } else if (e.target.classList.contains('btn-delete')) {
                const id = e.target.dataset.id;
                if (id) {
                    deleteGradPkg(id);
                }
            }
        });
    }
    
    // Event delegation for payment terms items container
    const ptItemsContainer = document.getElementById('pt-items');
    if (ptItemsContainer) {
        ptItemsContainer.addEventListener('click', function(e) {
            console.log('PT Container clicked:', e.target.className, e.target.dataset);
            try {
                if (e.target.classList.contains('btn-edit-pt')) {
                    const id = e.target.dataset.id;
                    console.log('Edit PT clicked, id:', id);
                    if (id) {
                        editPaymentTerm(id);
                    }
                } else if (e.target.classList.contains('btn-delete-pt')) {
                    const id = e.target.dataset.id;
                    console.log('Delete PT clicked, id:', id);
                    if (id) {
                        deletePaymentTerm(id);
                    }
                }
            } catch (err) {
                console.error('Error handling PT button click:', err);
                showToast('✕ Error: ' + err.message, 'error');
            }
        });
    }
    
    // Render graduation preview
    if (document.getElementById('grad-grid')) {
        console.log('Rendering graduation preview...');
        if (typeof renderGraduation === 'function') {
            renderGraduation();
        } else {
            console.error('renderGraduation function not found');
        }
    }

    // Render tabel Biaya Cetak — dipanggil terakhir setelah semua script ready
    if (typeof renderCetakTable === 'function') {
        renderCetakTable();
    }
});
</script>

<!-- ============================================================ -->
<!-- GRADUATION OVERRIDE — patch renderGraduation untuk pengaturan -->
<!-- ============================================================ -->
<script>
// Override renderPengaturan() — versi app-pages.js crash karena akses 'ov-oh'
// yang tidak ada di pengaturan.php. Override ini aman dan hanya render yang perlu.
function renderPengaturan() {
    if (typeof renderCetakTable === 'function') renderCetakTable();
    if (typeof renderGraduation === 'function') renderGraduation();
}

// Override renderGraduation() agar bekerja di pengaturan.php
// (app-pages.js versinya crash karena coba akses elemen halaman lain)
function renderGraduation() {
    // Pastikan GRAD terisi penuh
    if (!GRAD || !Array.isArray(GRAD.packages)) return;

    // 1. Isi dropdown gc-pkg (ada di halaman ini) dan k-grad-pkg (mungkin tidak ada)
    const opts = '<option value="">— Pilih paket —</option>' +
        GRAD.packages.map(p => `<option value="${p.id}">${p.name} — ${fmt(p.price)}</option>`).join('');
    ['gc-pkg', 'k-grad-pkg'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = opts;
    });

    // 2. Render preview kartu Paket Utama
    const gridEl = document.getElementById('grad-grid');
    if (gridEl) {
        gridEl.innerHTML = GRAD.packages.map((p, pi) => {
            const isFeat = p.color === 'feat';
            const isAcc  = p.color === 'acc';
            return `<div class="pkc ${isFeat ? 'feat-grad' : ''} ${isAcc ? 'feat' : ''}">
                <div class="pnum grad-accent" style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em">${isFeat ? '⭐ Complete Package' : isAcc ? '📸 Unggulan' : ''}</div>
                <div class="pname">${p.name}</div>
                <div class="pdesc" style="font-size:11px">${p.desc || ''}</div>
                <div class="pp grad" style="margin-top:10px">
                    <input class="edi" type="number" value="${p.price}"
                        onchange="GRAD.packages[${pi}].price=parseInt(this.value)||${p.price};renderGraduation()"
                        style="width:110px;font-size:18px;font-family:var(--font-d);color:var(--grad);text-align:right;border-color:var(--grad-light)">
                </div>
                <div class="pps">flat per event • incl. transport jabodetabek</div>
            </div>`;
        }).join('');
    }

    // 3. Render tabel Add-on (preview bawah)
    const addonEl = document.getElementById('grad-addon');
    if (addonEl) {
        addonEl.innerHTML = GRAD.addons.map((a, ai) =>
            `<tr><td>${a.name}</td><td>
                <input class="edi" type="number" value="${a.price}"
                    onchange="GRAD.addons[${ai}].price=parseInt(this.value)"
                    style="width:90px;text-align:right">
            </td></tr>`
        ).join('');
    }

    // 4. Render tabel Cetak Foto (preview bawah)
    const cetakEl = document.getElementById('grad-cetak');
    if (cetakEl) {
        cetakEl.innerHTML = GRAD.cetak.map((c, ci) =>
            `<tr><td>${c.name}</td><td>
                <input class="edi" type="number" value="${c.price}"
                    onchange="GRAD.cetak[${ci}].price=parseInt(this.value)"
                    style="width:70px;text-align:right">
                <span style="font-size:11px;color:var(--text3)">/lembar</span>
            </td></tr>`
        ).join('');
    }

    // 5. Render Kalkulator Graduation add-ons & cetak
    const gcAddonsEl = document.getElementById('gc-addons');
    if (gcAddonsEl) {
        gcAddonsEl.innerHTML = `
            <div class="ct">Add-on Graduation</div>
            ${GRAD.addons.map(a => `
                <div style="display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid var(--border);font-size:13px">
                    <input type="checkbox" id="gchk-${a.id}" onchange="gcUpdate()">
                    <span style="flex:1">${a.name}</span>
                    <span style="color:var(--text3);font-size:12px">${fmt(a.price)}</span>
                </div>`).join('')}
            <div class="ct mt10">Cetak Foto Tambahan</div>
            ${GRAD.cetak.map(c => `
                <div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border);font-size:13px">
                    <input type="checkbox" id="gchk-${c.id}" onchange="gcUpdate()">
                    <span style="flex:1">${c.name}</span>
                    <span style="color:var(--text3);font-size:12px">${fmt(c.price)}/lembar</span>
                    <input type="number" id="gqty-${c.id}" value="1" min="1" style="width:50px;display:none" oninput="gcUpdate()">
                </div>`).join('')}`;
        // attach cetak qty toggle
        GRAD.cetak.forEach(c => {
            const chk = document.getElementById('gchk-' + c.id);
            if (chk) chk.addEventListener('change', () => {
                const qi = document.getElementById('gqty-' + c.id);
                if (qi) qi.style.display = chk.checked ? '' : 'none';
            });
        });
    }

    gcUpdate();
}
</script>

<!-- ============================================================ -->
<!-- CETAK CRUD FUNCTIONS — Biaya Cetak Renjana Offset            -->
<!-- ============================================================ -->
<script>
// Override renderCetakTable dari app.js dengan versi CRUD
function renderCetakTable() {
    if (!CETAK_BASE || CETAK_BASE.length === 0) {
        CETAK_BASE = DEF_CETAK_BASE.map(r => ({...r, pages: {...r.pages}}));
    }
    const r = CETAK_BASE[curCetakRange];
    if (!r) return;
    const wrap = document.getElementById('cetak-table-wrap');
    if (!wrap) return;

    const pages = Object.keys(r.pages).map(Number).sort((a, b) => a - b);

    const rows = pages.map(p => `
        <tr>
            <td style="font-weight:500;white-space:nowrap">${p} hal</td>
            <td>
                <div style="display:flex;align-items:center;gap:5px">
                    <input type="number" value="${r.pages[p]}" min="0" step="1000"
                        style="width:105px;text-align:right;font-size:13px"
                        onchange="CETAK_BASE[${curCetakRange}].pages[${p}]=parseInt(this.value)||${r.pages[p]}"
                        title="Edit harga untuk ${p} halaman">
                    <span style="font-size:11px;color:var(--text3)">/buku</span>
                </div>
            </td>
            <td style="font-size:11px;color:var(--text3)">
                Handy <b>${fmt(Math.round(r.pages[p] * CETAK_F.handy))}</b> ·
                Minimal <b>${fmt(Math.round(r.pages[p] * CETAK_F.minimal))}</b> ·
                Large <b>${fmt(Math.round(r.pages[p] * CETAK_F.large))}</b>
            </td>
            <td>
                <button class="btn bs bsm" onclick="deleteHalamanTier(${p})"
                    title="Hapus tier ${p} halaman"
                    style="padding:2px 8px;font-size:12px;color:var(--danger);border-color:var(--danger)">✕</button>
            </td>
        </tr>`).join('');

    wrap.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <div style="font-size:12px;color:var(--accent);font-weight:600">${r.label}</div>
            <div style="font-size:11px;color:var(--text3)">${pages.length} tier halaman</div>
        </div>
        <table style="width:100%">
            <thead><tr>
                <th>Halaman</th>
                <th>Harga Base/Buku</th>
                <th>Efektif per Paket (setelah faktor)</th>
                <th style="width:40px"></th>
            </tr></thead>
            <tbody>${rows || '<tr><td colspan="4" style="text-align:center;color:var(--text3);padding:16px">Belum ada tier halaman. Tambah di bawah.</td></tr>'}</tbody>
        </table>`;
}

// Hapus satu tier halaman dari range aktif
function deleteHalamanTier(pages) {
    const r = CETAK_BASE[curCetakRange];
    if (!r || !confirm(`Hapus tier ${pages} halaman dari ${r.label}?`)) return;
    delete r.pages[pages];
    renderCetakTable();
    autoSaveCetakBase();
}

// Tambah tier halaman baru ke range aktif
function addHalamanTier() {
    const pagesEl = document.getElementById('new-hal-pages');
    const priceEl = document.getElementById('new-hal-price');
    const pages = parseInt(pagesEl?.value);
    const price = parseInt(priceEl?.value);
    if (!pages || pages < 1) { showToast('Masukkan jumlah halaman yang valid', 'error'); pagesEl?.focus(); return; }
    if (!price || price < 0) { showToast('Masukkan harga yang valid', 'error'); priceEl?.focus(); return; }
    const r = CETAK_BASE[curCetakRange];
    if (!r) return;
    r.pages[pages] = price;
    pagesEl.value = '';
    priceEl.value = '';
    renderCetakTable();
    autoSaveCetakBase();
}

// Hapus range dari CETAK_BASE
function deleteCetakRange(e, idx) {
    e.stopPropagation();
    const r = CETAK_BASE[idx];
    if (!r || !confirm(`Hapus range "${r.label}" secara permanen?\n\nSemua data harga dalam range ini akan hilang.`)) return;
    CETAK_BASE.splice(idx, 1);
    curCetakRange = Math.max(0, Math.min(curCetakRange, CETAK_BASE.length - 1));
    rebuildRangeBtns();
    renderCetakTable();
    autoSaveCetakBase();
}

// Rebuild range buttons di DOM setelah add/delete
function rebuildRangeBtns() {
    const btnsEl = document.getElementById('cetak-range-btns');
    if (!btnsEl) return;
    btnsEl.innerHTML = CETAK_BASE.map((r, i) => `
        <button class="btn ${i === curCetakRange ? 'bp' : 'bs'} bsm cetak-range-btn"
            onclick="setCetakRange(${i}, this)" style="font-size:11px;position:relative">
            ${r.label}
            <span class="cetak-del-btn" onclick="deleteCetakRange(event,${i})"
                title="Hapus range"
                style="margin-left:5px;color:${i===curCetakRange?'rgba(255,255,255,.7)':'var(--danger)'};font-weight:700;font-size:13px;line-height:1">×</span>
        </button>`).join('');
}

// Modal: Tambah Range Baru
function showAddRangeModal() {
    const el = document.getElementById('modal-add-range');
    if (el) { el.style.display = 'flex'; }
}
function closeAddRangeModal() {
    const el = document.getElementById('modal-add-range');
    if (el) { el.style.display = 'none'; }
}
function confirmAddRange() {
    const lo = parseInt(document.getElementById('new-range-lo')?.value);
    const hi = parseInt(document.getElementById('new-range-hi')?.value);
    const labelInp = document.getElementById('new-range-label')?.value?.trim();
    if (!lo || !hi || lo >= hi) {
        showToast('Nilai min/max tidak valid (min harus < max)', 'error'); return;
    }
    // Cek overlap dengan range yang ada
    const overlap = CETAK_BASE.some(r => !(hi < r.lo || lo > r.hi));
    if (overlap) {
        showToast('Range ini tumpang tindih dengan range yang sudah ada', 'error'); return;
    }
    const label = labelInp || `${lo}–${hi} siswa`;
    // Default pages dari range terdekat
    const closest = CETAK_BASE.reduce((a, b) => Math.abs((a.lo+a.hi)/2 - (lo+hi)/2) < Math.abs((b.lo+b.hi)/2 - (lo+hi)/2) ? a : b);
    const newRange = { lo, hi, label, pages: {...closest.pages} };
    CETAK_BASE.push(newRange);
    CETAK_BASE.sort((a, b) => a.lo - b.lo);
    curCetakRange = CETAK_BASE.findIndex(r => r.lo === lo && r.hi === hi);
    closeAddRangeModal();
    document.getElementById('new-range-lo').value = '';
    document.getElementById('new-range-hi').value = '';
    document.getElementById('new-range-label').value = '';
    rebuildRangeBtns();
    renderCetakTable();
    autoSaveCetakBase();
    showToast(`Range "${label}" berhasil ditambahkan`, 'success');
}

// Close modal on backdrop click
document.getElementById('modal-add-range')?.addEventListener('click', function(e) {
    if (e.target === this) closeAddRangeModal();
});

// Auto-save cetak base ke master API
async function autoSaveCetakBase() {
    try {
        const res = await fetch('/api/master-data.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: 'cetak_base', data: CETAK_BASE })
        });
        const result = await res.json();
        if (result.success) {
            const s = document.getElementById('ov-cetak-status');
            if (s) { s.style.display = 'inline'; s.textContent = '✓ Tersimpan otomatis'; setTimeout(() => s.style.display = 'none', 2500); }
        }
    } catch(e) { console.warn('Auto-save cetak failed:', e); }
}

// Override saveCetakBase dari app.js agar juga rebuild buttons
const _origSaveCetakBase = typeof saveCetakBase === 'function' ? saveCetakBase : null;
function saveCetakBase() {
    saveSettingsToAPI('cetak_base', CETAK_BASE).then(ok => {
        if (ok) kalcUpdate && kalcUpdate();
    });
    // Juga simpan ke master-data API
    fetch('/api/master-data.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'cetak_base', data: CETAK_BASE })
    });
}

// Override resetCetakBase agar juga rebuild buttons
function resetCetakBase() {
    if (!confirm('Reset semua data Biaya Cetak ke default Renjana Offset?\n\nPerubahan manual akan hilang.')) return;
    CETAK_BASE = DEF_CETAK_BASE.map(r => ({...r, pages: {...r.pages}}));
    curCetakRange = 0;
    rebuildRangeBtns();
    renderCetakTable();
    autoSaveCetakBase();
}

// Override setCetakRange agar update button colors dengan benar
function setCetakRange(idx, btn) {
    curCetakRange = idx;
    document.querySelectorAll('#cetak-range-btns button').forEach((b, i) => {
        b.className = `btn ${i === idx ? 'bp' : 'bs'} bsm cetak-range-btn`;
        const delSpan = b.querySelector('.cetak-del-btn');
        if (delSpan) delSpan.style.color = i === idx ? 'rgba(255,255,255,.7)' : 'var(--danger)';
    });
    renderCetakTable();
}
</script>
</body>
</html>
