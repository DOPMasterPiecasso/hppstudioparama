<?php
/**
 * Parama HPP - Master Data API
 * 
 * API terpusat untuk semua data harga dan pengaturan
 * Halaman pengaturan.php adalah master editor, semua halaman lain mengambil data dari sini
 * 
 * Endpoints:
 * GET /api/master-data.php?action=get_all           — Semua data
 * GET /api/master-data.php?action=get_overhead      — Overhead saja
 * GET /api/master-data.php?action=get_fullservice   — Full Service pricing
 * GET /api/master-data.php?action=get_alacarte      — À La Carte packages
 * GET /api/master-data.php?action=get_addons        — Add-ons
 * GET /api/master-data.php?action=get_cetak         — Cetak base
 * GET /api/master-data.php?action=get_graduation    — Graduation packages
 * POST /api/master-data.php                         — Update master data
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../auth/AuthMiddleware.php';

$user = requireAuth();
header('Content-Type: application/json; charset=utf-8');

try {
    $pdo = getDB();
    $method = $_SERVER['REQUEST_METHOD'];
    $action = $_GET['action'] ?? 'get_all';
    
    // GET — Fetch data dari master
    if ($method === 'GET') {
        $response = [];
        
        switch ($action) {
            case 'get_all':
                // Return ALL master data sekaligus
                $response = [
                    'overhead' => getMasterOverhead($pdo),
                    'cetak_f' => getMasterCetakFactors($pdo),
                    'cetak_base' => getMasterCetakBase($pdo),
                    'alc_f' => getMasterAlaCarteFactors($pdo),
                    'fs' => getMasterFullService($pdo),
                    'addon_data' => getMasterAddons($pdo),
                    'grad' => getMasterGraduation($pdo),
                    'timestamp' => date('Y-m-d H:i:s'),
                ];
                break;
                
            case 'get_overhead':
                $response = getMasterOverhead($pdo);
                break;
                
            case 'get_cetak_factors':
                $response = getMasterCetakFactors($pdo);
                break;
                
            case 'get_cetak_base':
                $response = getMasterCetakBase($pdo);
                break;
                
            case 'get_alacarte_factors':
                $response = getMasterAlaCarteFactors($pdo);
                break;
                
            case 'get_fullservice':
                $response = getMasterFullService($pdo);
                break;
                
            case 'get_addons':
                $response = getMasterAddons($pdo);
                break;
                
            case 'get_graduation':
                $response = getMasterGraduation($pdo);
                break;
                
            default:
                throw new Exception('Action not recognized: ' . $action);
        }
        
        echo json_encode(['success' => true, 'data' => $response], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // POST — Update master data (manager/admin only)
    if ($method === 'POST') {
        requireRoleAPI('admin', 'manager');
        
        $body = json_decode(file_get_contents('php://input'), true) ?? [];
        $type = $body['type'] ?? null;
        
        if (!$type) {
            throw new Exception('Type parameter required');
        }
        
        $response = updateMasterData($pdo, $type, $body);
        
        echo json_encode(['success' => true, 'message' => 'Master data updated', 'data' => $response], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // Method not allowed
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    exit;
}

// ============================================================
// GETTER FUNCTIONS - Master Data
// ============================================================

function getMasterOverhead($pdo) {
    // Load dari settings.json
    $settingsPath = __DIR__ . '/../data/settings.json';
    if (file_exists($settingsPath)) {
        $data = json_decode(file_get_contents($settingsPath), true);
        if (isset($data['overhead'])) {
            return $data['overhead'];
        }
    }
    
    // Fallback ke database
    $stmt = $pdo->query("SELECT category, amount FROM overhead ORDER BY id");
    $result = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $result[$row['category']] = (int)$row['amount'];
    }
    return $result;
}

function getMasterCetakFactors($pdo) {
    $settingsPath = __DIR__ . '/../data/settings.json';
    if (file_exists($settingsPath)) {
        $data = json_decode(file_get_contents($settingsPath), true);
        if (isset($data['pricing_factors']['cetak'])) {
            return $data['pricing_factors']['cetak'];
        }
    }
    
    return [
        'handy' => 1.0,
        'minimal' => 0.95,
        'large' => 1.15
    ];
}

function getMasterCetakBase($pdo) {
    $path = __DIR__ . '/../data/cetak_base.json';
    if (file_exists($path)) {
        $data = json_decode(file_get_contents($path), true);
        return is_array($data) ? $data : [];
    }
    return [];
}

function getMasterAlaCarteFactors($pdo) {
    $settingsPath = __DIR__ . '/../data/settings.json';
    if (file_exists($settingsPath)) {
        $data = json_decode(file_get_contents($settingsPath), true);
        if (isset($data['pricing_factors']['alacarte'])) {
            return $data['pricing_factors']['alacarte'];
        }
    }
    
    return [
        'ebook' => 0.72,
        'editcetak' => 0.62,
        'desain' => 0.22,
        'cetakonly' => 0.30
    ];
}

function getMasterFullService($pdo) {
    $stmt = $pdo->query("
        SELECT package_type, min_students, max_students, price_per_book, max_pages
        FROM packages_fullservice
        ORDER BY package_type, min_students
    ");
    
    $result = ['handy' => [], 'minimal' => [], 'large' => []];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $result[$row['package_type']][] = [
            'min' => (int)$row['min_students'],
            'max' => (int)$row['max_students'],
            'price' => (int)$row['price_per_book'],
            'pages' => (int)$row['max_pages']
        ];
    }
    
    return $result;
}

function getMasterAddons($pdo) {
    $path = __DIR__ . '/../data/addons.json';
    if (file_exists($path)) {
        $data = json_decode(file_get_contents($path), true);
        return $data;
    }
    return [];
}

function getMasterGraduation($pdo) {
    $path = __DIR__ . '/../data/graduation.json';
    if (file_exists($path)) {
        $data = json_decode(file_get_contents($path), true);
        return $data;
    }
    return ['packages' => [], 'addons' => [], 'cetak' => []];
}

// ============================================================
// UPDATE FUNCTION - Master Data
// ============================================================

function updateMasterData($pdo, $type, $body) {
    switch ($type) {
        case 'overhead':
            return updateOverhead($pdo, $body['data'] ?? []);
            
        case 'cetak_factors':
            return updateCetakFactors($pdo, $body['data'] ?? []);
            
        case 'cetak_base':
            return updateCetakBase($pdo, $body['data'] ?? []);
            
        case 'alacarte_factors':
            return updateAlaCarteFactors($pdo, $body['data'] ?? []);
            
        case 'fullservice':
            return updateFullService($pdo, $body['data'] ?? []);
            
        case 'addons':
            return updateAddons($pdo, $body['data'] ?? []);
            
        case 'graduation':
            return updateGraduation($pdo, $body['data'] ?? []);
        
        case 'payment_terms':
            return updatePaymentTerms($pdo, $body['data'] ?? []);
            
        default:
            throw new Exception('Unknown update type: ' . $type);
    }
}

function updateOverhead($pdo, $data) {
    $settingsPath = __DIR__ . '/../data/settings.json';
    $settings = file_exists($settingsPath) ? json_decode(file_get_contents($settingsPath), true) : [];
    
    $settings['overhead'] = $data;
    file_put_contents($settingsPath, json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    return $data;
}

function updateCetakFactors($pdo, $data) {
    $settingsPath = __DIR__ . '/../data/settings.json';
    $settings = file_exists($settingsPath) ? json_decode(file_get_contents($settingsPath), true) : [];
    
    if (!isset($settings['pricing_factors'])) {
        $settings['pricing_factors'] = [];
    }
    $settings['pricing_factors']['cetak'] = $data;
    
    file_put_contents($settingsPath, json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    return $data;
}

function updateCetakBase($pdo, $data) {
    $path = __DIR__ . '/../data/cetak_base.json';
    file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    return $data;
}

function updateAlaCarteFactors($pdo, $data) {
    $settingsPath = __DIR__ . '/../data/settings.json';
    $settings = file_exists($settingsPath) ? json_decode(file_get_contents($settingsPath), true) : [];
    
    if (!isset($settings['pricing_factors'])) {
        $settings['pricing_factors'] = [];
    }
    $settings['pricing_factors']['alacarte'] = $data;
    
    file_put_contents($settingsPath, json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    return $data;
}

function updateFullService($pdo, $data) {
    // Full service data di-simpan di database
    // Implementasi sesuai dengan struktur database Anda
    // Untuk sekarang, return data
    return $data;
}

function updateAddons($pdo, $data) {
    $path = __DIR__ . '/../data/addons.json';
    file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    return $data;
}

function updateGraduation($pdo, $data) {
    $path = __DIR__ . '/../data/graduation.json';
    file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    return $data;
}

function updatePaymentTerms($pdo, $data) {
    $path = __DIR__ . '/../data/payment_terms.json';
    
    // Ensure data directory exists
    $dataDir = dirname($path);
    if (!is_dir($dataDir)) {
        mkdir($dataDir, 0755, true);
    }
    
    // Try to write file
    $result = file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    if ($result === false) {
        throw new Exception('Failed to write payment_terms.json - check file permissions');
    }
    
    return $data;
}
?>
